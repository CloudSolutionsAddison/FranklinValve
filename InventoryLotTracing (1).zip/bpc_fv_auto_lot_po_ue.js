/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 *
 * Franklin Valve — Auto Lot: Purchase Order (User Event Script)
 *
 * ============================================================================
 *  PURPOSE
 * ============================================================================
 *  Runs on Purchase Order beforeSubmit. For every lot-numbered item line it:
 *    1. Reads the quantity from the PO line
 *    2. Looks up the Vendor Part Number mapping (vendor + item → vendor code)
 *    3. Populates the inventory detail subrecord on that PO line:
 *         - receiptinventorynumber = vendor code (lot number)
 *         - quantity               = PO line quantity
 *         - binnumber              = 4327  (11-QA-INSP @ FV - Warehouse)
 *         - inventorystatus        = 1
 *    4. Blocks the PO save if any lot-numbered line is missing a mapping
 *
 * ============================================================================
 *  DEPLOYMENT
 * ============================================================================
 *  Applies To : Purchase Order
 *  Events     : beforeSubmit (create + edit)
 *
 * Functional Design Ref: FDD v0.3, Section 1.1
 */
define([
    'N/search',
    'N/error',
    'N/log'
], function (search, error, log) {

    'use strict';

    /* ------------------------------------------------------------------ *
     *  CONSTANTS  (mirror the Suitelet — keep in sync)                    *
     * ------------------------------------------------------------------ */

    var ITEM_SUBLIST = 'item';
    var INV_DETAIL   = 'inventorydetail';
    var INV_ASSIGN   = 'inventoryassignment';

    var VENDOR_PART_NUM_RECORD = 'customrecord_bpc_fv_vpn';
    var VPN_VENDOR = 'name';                          // <-- verify
    var VPN_ITEM   = 'custrecord_bpc_fv_item';
    var VPN_CODE   = 'custrecord_bpc_ui_vendorlist';  // <-- verify

    var DEFAULT_BIN_ID        = 4327;   // 11-QA-INSP @ FV - Warehouse
    var DEFAULT_INV_STATUS_ID = 1;

    /* ------------------------------------------------------------------ *
     *  LOGGING                                                            *
     * ------------------------------------------------------------------ */

    var DEBUG = true;

    function fmt(d) {
        if (d === undefined || d === null) return '';
        return (typeof d === 'object') ? JSON.stringify(d) : String(d);
    }
    function dbg(stage, d)   { if (DEBUG) log.debug({ title: 'FV_AutoLot_PO_UE:' + stage, details: fmt(d) }); }
    function audit(stage, d) { log.audit({ title: 'FV_AutoLot_PO_UE:' + stage, details: fmt(d) }); }
    function errLog(stage, e){ log.error({ title: 'FV_AutoLot_PO_UE:' + stage, details: (e && e.stack) || (e && e.message) || fmt(e) }); }

    /* ------------------------------------------------------------------ *
     *  CACHES                                                             *
     * ------------------------------------------------------------------ */

    var lotItemCache    = {};
    var vendorCodeCache = {};

    /* ================================================================== *
     *  ENTRY POINT — beforeSubmit                                         *
     * ================================================================== */

    function beforeSubmit(context) {
        if (context.type !== context.UserEventType.CREATE &&
            context.type !== context.UserEventType.EDIT) return;

        var rec = context.newRecord;
        var vendorId = rec.getValue('entity');

        audit('beforeSubmit.enter', { poId: rec.id, type: context.type, vendor: vendorId });

        if (!vendorId) {
            dbg('beforeSubmit.skip', 'no vendor set');
            return;
        }

        var lineCount = rec.getLineCount({ sublistId: ITEM_SUBLIST });
        dbg('lineCount', lineCount);

        var missing   = [];
        var populated = 0;

        for (var i = 0; i < lineCount; i++) {
            try {
                var result = processLine(rec, i, vendorId);
                if (result && result.missing)    missing.push(result.missing);
                else if (result && result.populated) populated++;
            } catch (e) {
                errLog('line[' + i + ']', e);
                throw e;
            }
        }

        audit('beforeSubmit.summary', { populated: populated, missing: missing.length });

        // ── Block the PO save if mappings are missing ────────────────────
        if (missing.length) {
            throw error.create({
                name:    'FV_MISSING_VENDOR_MAPPING',
                message: 'This Purchase Order cannot be saved. The following ' +
                         'lot-numbered items have no active Vendor Part Number ' +
                         'mapping for this vendor:\n\n' + missing.join('\n') +
                         '\n\nCreate the mapping(s) and try again.',
                notifyOff: true
            });
        }
    }

    /* ------------------------------------------------------------------ *
     *  LINE PROCESSING                                                    *
     * ------------------------------------------------------------------ */

    function processLine(rec, line, vendorId) {
        var itemId = rec.getSublistValue({ sublistId: ITEM_SUBLIST, fieldId: 'item', line: line });
        if (!itemId) return null;

        // Only care about lot-numbered items
        if (!isLotNumbered(itemId)) {
            dbg('line[' + line + '].skipNonLot', itemId);
            return null;
        }

        // Read quantity directly from the PO line
        var quantity = parseFloat(
            rec.getSublistValue({ sublistId: ITEM_SUBLIST, fieldId: 'quantity', line: line })
        ) || 0;
        dbg('line[' + line + '].qty', quantity);

        if (quantity <= 0) {
            dbg('line[' + line + '].skipZeroQty', itemId);
            return null;
        }

        // Look up vendor code
        var vendorCode = lookupVendorCode(vendorId, itemId);
        dbg('line[' + line + '].vendorCode', vendorCode);

        if (!vendorCode) {
            var itemName = rec.getSublistText({ sublistId: ITEM_SUBLIST, fieldId: 'item', line: line });
            audit('line[' + line + '].missingMapping', { item: itemName, vendor: vendorId });
            return { missing: 'Line ' + (line + 1) + ': ' + itemName + ' (qty ' + quantity + ')' };
        }

        // ── Populate inventory detail subrecord ─────────────────────────
        populateInventoryDetail(rec, line, vendorCode, quantity);
        audit('line[' + line + '].done', { item: itemId, lot: vendorCode, qty: quantity, bin: DEFAULT_BIN_ID });
        return { populated: true };
    }

    /* ------------------------------------------------------------------ *
     *  INVENTORY DETAIL WRITE                                             *
     * ------------------------------------------------------------------ */

    function populateInventoryDetail(rec, line, vendorCode, quantity) {
        var invDetail = rec.getSublistSubrecord({
            sublistId: ITEM_SUBLIST,
            fieldId:   INV_DETAIL,
            line:      line
        });

        if (!invDetail) {
            throw error.create({
                name:    'FV_NO_INV_DETAIL_SUBRECORD',
                message: 'Inventory Detail subrecord unavailable on PO line ' + (line + 1) + '.'
            });
        }

        var count = invDetail.getLineCount({ sublistId: INV_ASSIGN });
        dbg('populate.existing', { line: line, count: count });

        // Clear extra assignment lines, keep line 0
        for (var j = count - 1; j >= 1; j--) {
            invDetail.removeLine({ sublistId: INV_ASSIGN, line: j });
        }
        if (count === 0) {
            invDetail.insertLine({ sublistId: INV_ASSIGN, line: 0 });
        }

        // Set lot number
        invDetail.setSublistValue({ sublistId: INV_ASSIGN, fieldId: 'receiptinventorynumber', line: 0, value: vendorCode });
        dbg('populate.setLot', { line: line, vendorCode: vendorCode });

        // Set quantity
        invDetail.setSublistValue({ sublistId: INV_ASSIGN, fieldId: 'quantity', line: 0, value: quantity });
        dbg('populate.setQty', { line: line, quantity: quantity });

        // Set bin
        try {
            //invDetail.setSublistValue({ sublistId: INV_ASSIGN, fieldId: 'binnumber', line: 0, value: DEFAULT_BIN_ID });
            var binAfter = invDetail.getSublistValue({ sublistId: INV_ASSIGN, fieldId: 'binnumber', line: 0 });
            dbg('populate.setBin', { line: line, requested: DEFAULT_BIN_ID, actual: binAfter, stuck: (String(binAfter) === String(DEFAULT_BIN_ID)) });
        } catch (eBin) {
            errLog('populate.setBin.FAILED', eBin);
        }

        // Set inventory status
        try {
            invDetail.setSublistValue({ sublistId: INV_ASSIGN, fieldId: 'inventorystatus', line: 0, value: DEFAULT_INV_STATUS_ID });
            var statusAfter = invDetail.getSublistValue({ sublistId: INV_ASSIGN, fieldId: 'inventorystatus', line: 0 });
            dbg('populate.setStatus', { line: line, requested: DEFAULT_INV_STATUS_ID, actual: statusAfter, stuck: (String(statusAfter) === String(DEFAULT_INV_STATUS_ID)) });
        } catch (eStatus) {
            errLog('populate.setStatus.FAILED', eStatus);
        }

        dbg('populate.done', { line: line, assignmentsNow: invDetail.getLineCount({ sublistId: INV_ASSIGN }) });
    }

    /* ------------------------------------------------------------------ *
     *  HELPERS                                                            *
     * ------------------------------------------------------------------ */

    function isLotNumbered(itemId) {
        var key = String(itemId);
        if (lotItemCache.hasOwnProperty(key)) return lotItemCache[key];
        var isLot = false;
        try {
            var f = search.lookupFields({ type: search.Type.ITEM, id: itemId, columns: ['islotitem'] });
            isLot = f.islotitem === true || f.islotitem === 'T';
        } catch (e) { errLog('isLotNumbered[' + key + ']', e); }
        lotItemCache[key] = isLot;
        return isLot;
    }

    function lookupVendorCode(vendorId, itemId) {
        var key = vendorId + '|' + itemId;
        if (vendorCodeCache.hasOwnProperty(key)) return vendorCodeCache[key];

        var filters = [
            [VPN_CODE, 'anyof', vendorId],
            'AND',
            [VPN_ITEM,   'anyof', itemId],
            'AND',
            ['isinactive', 'is', 'F']
        ];
        dbg('vendorCode.search', { vendor: vendorId, item: itemId });

        var code = null;
        try {
            var s = search.create({ type: VENDOR_PART_NUM_RECORD, filters: filters, columns: [VPN_VENDOR] });
            s.run().each(function (r) { code = r.getValue(VPN_VENDOR); return false; });
            vendorCodeCache[key] = code;
        } catch (e) { errLog('vendorCode', e); }

        return code;
    }

    return {
        beforeSubmit: beforeSubmit
    };
});
