/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 *
 * Franklin Valve — Auto Lot: Work Order Component Issue (Subprocess 1.2)
 *
 * When an Assembly Build / Work Order Issue is saved, this script
 * auto-selects the lot(s) for every lot-tracked component line using the
 * shared lot selection algorithm.
 *
 * If available lot quantity is insufficient, the save is blocked (FR-12, KBD-07).
 *
 * Functional Design Ref: FDD v0.3, Section 1.2 (FR-09)
 */
define([
    'N/record',
    'N/log',
    'N/error',
    './bpc_fv_auto_lot_util'
], function (record, log, error, util) {

    var SCRIPT_ID = 'FV_AutoLot_WOIssue';

    /**
     * beforeSubmit — fires on create of Assembly Build.
     */
    function beforeSubmit(context) {
        log.debug(SCRIPT_ID + ' | beforeSubmit Entry', 'Event type: ' + context.type);

        if (context.type !== context.UserEventType.CREATE) {
            log.debug(SCRIPT_ID + ' | Skipped', 'Event type "' + context.type + '" is not CREATE. Exiting.');
            return;
        }

        var rec = context.newRecord;
        log.debug(SCRIPT_ID + ' | Record Info',
            'Record type: ' + rec.type + ' | Record ID: ' + (rec.id || 'NEW'));

        // Work order component lines live on the 'component' sublist
        var sublistId = 'component';
        var lineCount = rec.getLineCount({ sublistId: sublistId });
        log.debug(SCRIPT_ID + ' | Component Lines', 'Total component lines: ' + lineCount);

        var errors = [];

        for (var i = 0; i < lineCount; i++) {
            var itemId = rec.getSublistValue({
                sublistId: sublistId,
                fieldId:   'item',
                line:      i
            });

            // Skip non-lot-numbered items
            if (!util.isLotNumbered(itemId)) {
                log.debug(SCRIPT_ID + ' | Line ' + (i + 1),
                    'Item ' + itemId + ' is not lot-numbered. Skipping.');
                continue;
            }

            var quantity = parseFloat(rec.getSublistValue({
                sublistId: sublistId,
                fieldId:   'quantity',
                line:      i
            })) || 0;

            if (quantity <= 0) {
                log.debug(SCRIPT_ID + ' | Line ' + (i + 1),
                    'Item ' + itemId + ' has quantity ' + quantity + '. Skipping.');
                continue;
            }

            var locationId = rec.getSublistValue({
                sublistId: sublistId,
                fieldId:   'location',
                line:      i
            });

            log.debug(SCRIPT_ID + ' | Line ' + (i + 1) + ' Processing',
                'Item: ' + itemId + ' | Qty: ' + quantity + ' | Location: ' + locationId);

            // Query available lots (FR-09)
            var availableLots = util.getAvailableLots(itemId, locationId);
            log.debug(SCRIPT_ID + ' | Line ' + (i + 1) + ' Available Lots',
                'Found ' + availableLots.length + ' lot(s): ' +
                JSON.stringify(availableLots.map(function (l) {
                    return { lot: l.lotNumber, qty: l.quantity };
                })));

            // Run lot selection algorithm
            var result = util.selectLots(availableLots, quantity);

            if (!result.success) {
                var itemName = rec.getSublistText({
                    sublistId: sublistId,
                    fieldId:   'item',
                    line:      i
                });
                var errMsg = 'Component line ' + (i + 1) + ' (' + itemName + '): ' +
                    'Required ' + quantity + ' units but only ' +
                    (quantity - result.shortfall) + ' available across all lots.';
                log.error(SCRIPT_ID + ' | Line ' + (i + 1) + ' Shortfall', errMsg);
                errors.push(errMsg);
                continue;
            }

            log.audit(SCRIPT_ID + ' | Line ' + (i + 1) + ' Lots Selected',
                'Selected ' + result.lines.length + ' lot(s) for qty=' + quantity +
                ' | Selections: ' + JSON.stringify(result.lines));

            // Write inventory detail lines
            util.writeInventoryDetail(rec, sublistId, i, result.lines);
            log.debug(SCRIPT_ID + ' | Line ' + (i + 1) + ' Detail Written',
                'Inventory detail written successfully for ' + result.lines.length + ' lot(s).');
        }

        if (errors.length > 0) {
            log.error(SCRIPT_ID + ' | Save Blocked',
                'Blocking save due to ' + errors.length + ' shortfall error(s):\n' + errors.join('\n'));
            throw error.create({
                name:    'FV_LOT_SHORTFALL',
                message: 'Auto Lot Consumption blocked — insufficient lot ' +
                         'quantity on work order component(s):\n\n' +
                         errors.join('\n'),
                notifyOff: false
            });
        }

        log.debug(SCRIPT_ID + ' | beforeSubmit Exit', 'Completed successfully. Lines processed: ' + lineCount);
    }

    return {
        beforeSubmit: beforeSubmit
    };
});