/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 *
 * Franklin Valve — Auto Lot: PO "Receive with Auto-Lot" Button (User Event)
 *
 * ============================================================================
 *  PURPOSE
 * ============================================================================
 *  Adds a "Receive with Auto-Lot" button to the Purchase Order view. The
 *  button hands off to a client-script function that redirects the user to
 *  the server-side receive Suitelet (bpc_fv_auto_lot_receive_sl.js), passing
 *  the PO id. All the real work happens in the Suitelet + the Item Receipt UE.
 *
 * ============================================================================
 *  SETUP  (do this AFTER deploying the Suitelet)
 * ============================================================================
 *  1. Put bpc_fv_po_receive_button_cs.js in the SAME File Cabinet folder as
 *     this script (the clientScriptModulePath below is relative: './...').
 *     If you keep them in different folders, change the path accordingly.
 *  2. Set SUITELET_SCRIPT_ID / SUITELET_DEPLOY_ID to the Suitelet's IDs.
 *  3. Deploy this UE on Purchase Order.
 *
 * Functional Design Ref: FDD v0.3, Section 1.1
 */
define([
    'N/url',
    'N/log'
], function (url, log) {

    'use strict';

    // >>> SET THESE to the deployed Suitelet's IDs <<<
    var SUITELET_SCRIPT_ID = 'customscript_bpc_fv_autoreceive_sl';
    var SUITELET_DEPLOY_ID  = 'customdeploy1';

    // Relative path to the click-handler client script (same folder as this file).
    var BUTTON_CS_PATH = './bpc_fv_po_receive_button_cs.js';

    function beforeLoad(context) {
        // Action button belongs on the rendered record view.
        if (context.type !== context.UserEventType.VIEW) return;

        var rec  = context.newRecord;
        var poId = rec.id;
        if (!poId) return;

        // OPTIONAL receivability gate: uncomment and adapt if you only want the
        // button on POs that still have something to receive. Status text is
        // account/localization dependent, so left off by default.
        // var status = rec.getValue('status');
        // if (status === 'Fully Received' || status === 'Closed') return;

        var slUrl;
        try {
            slUrl = url.resolveScript({
                scriptId:     SUITELET_SCRIPT_ID,
                deploymentId: SUITELET_DEPLOY_ID,
                params:       { poid: poId }
            });
        } catch (e) {
            // If the Suitelet isn't deployed / IDs are wrong, skip the button
            // rather than break the PO form.
            log.error('FV_PO_Button_UE', 'resolveScript failed: ' + ((e && e.message) || e));
            return;
        }

        var form = context.form;
        form.clientScriptModulePath = BUTTON_CS_PATH;
        form.addButton({
            id:           'custpage_fv_autoreceive',
            label:        'Receive with Auto-Lot',
            functionName: "fvOpenAutoReceive('" + slUrl + "')"
        });
    }

    return { beforeLoad: beforeLoad };
});
