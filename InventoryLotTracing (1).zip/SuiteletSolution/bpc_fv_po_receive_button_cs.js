/**
 * @NApiVersion 2.1
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 *
 * Franklin Valve — Auto Lot: PO "Receive with Auto-Lot" Button (Client Script)
 *
 * ============================================================================
 *  PURPOSE
 * ============================================================================
 *  Click handler for the "Receive with Auto-Lot" button added by
 *  bpc_fv_po_receive_button_ue.js. The button's functionName passes the fully
 *  resolved Suitelet URL (with the PO id already in it), so this script has
 *  nothing to build or look up — it just navigates.
 *
 *  This does NOT need its own script record or deployment. It is attached to
 *  the PO form dynamically via form.clientScriptModulePath in the UE; it only
 *  needs to exist in the File Cabinet at the path the UE points to.
 *
 * Functional Design Ref: FDD v0.3, Section 1.1
 */
define([], function () {

    'use strict';

    function pageInit() {
        // Required client-script entry point. No-op.
    }

    /**
     * Invoked by the PO button. suiteletUrl is injected by the UE via the
     * button's functionName, so it already carries ?poid=<id>.
     */
    function fvOpenAutoReceive(suiteletUrl) {
        if (!suiteletUrl) return;
        window.location.href = suiteletUrl;
    }

    return {
        pageInit:          pageInit,
        fvOpenAutoReceive: fvOpenAutoReceive
    };
});
