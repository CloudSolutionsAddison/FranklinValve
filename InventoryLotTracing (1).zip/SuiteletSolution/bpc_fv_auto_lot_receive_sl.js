/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 *
 * Franklin Valve — Receive with Auto-Lot (Suitelet)
 *
 * ============================================================================
 *  PURPOSE
 * ============================================================================
 *  The native Item Receipt form cannot be saved interactively for lot-numbered
 *  items because NetSuite's client-side validation blocks before the UE
 *  beforeSubmit can populate the inventory-detail subrecord.
 *
 *  This Suitelet bypasses the browser entirely and is SELF-CONTAINED:
 *    1. Transforms the Purchase Order → Item Receipt  (record.transform)
 *    2. Marks all lines for receiving  (itemreceive = true)
 *    3. For each lot-numbered line, looks up the vendor-part-number mapping
 *       and populates the inventory-detail subrecord directly
 *    4. Saves the receipt
 *    5. Redirects the user to the newly created Item Receipt
 *
 *  The UE beforeSubmit on Item Receipt is still in place as a safety net
 *  for receipts created by other means, but this Suitelet does NOT depend
 *  on it — all lot assignment happens here before .save().
 *
 * ============================================================================
 *  DEPLOYMENT
 * ============================================================================
 *  Script Type : Suitelet
 *  Status      : Released
 *  Available Without Login : No
 *  URL parameter: poid  (internal ID of the Purchase Order)
 *
 *  The "Receive with Auto-Lot" button on the PO form should navigate to:
 *    /app/site/hosting/scriptlet.nl?script=<SCRIPT_ID>&deploy=<DEPLOY_ID>&poid={id}
 *
 * Functional Design Ref: FDD v0.3, Section 1.1
 */
define([
    'N/record',
    'N/search',
    'N/redirect',
    'N/error',
    'N/log',
    'N/ui/serverWidget'
], function (record, search, redirect, error, log, serverWidget) {

    'use strict';

    /* ------------------------------------------------------------------ *
     *  CONSTANTS  (mirror the UE script — keep in sync)                   *
     * ------------------------------------------------------------------ */

    var ITEM_SUBLIST = 'item';
    var INV_DETAIL   = 'inventorydetail';
    var INV_ASSIGN   = 'inventoryassignment';

    var VENDOR_PART_NUM_RECORD = 'customrecord_bpc_fv_vpn';
    var VPN_VENDOR = 'name';                          // <-- verify
    var VPN_ITEM   = 'custrecord_bpc_fv_item';
    var VPN_CODE   = 'custrecord_bpc_ui_vendorlist';  // <-- verify

    // >>> REPLACE with the actual internal IDs from the target account <<<
    var DEFAULT_BIN_ID        = 4327;
    var DEFAULT_INV_STATUS_ID = 1;

    /* ------------------------------------------------------------------ *
     *  LOGGING                                                            *
     * ------------------------------------------------------------------ */

    var DEBUG = true;

    function fmt(d) {
        if (d === undefined || d === null) return '';
        return (typeof d === 'object') ? JSON.stringify(d) : String(d);
    }
    function dbg(stage, d)     { if (DEBUG) log.debug({ title: 'FV_AutoLot_SL:' + stage, details: fmt(d) }); }
    function audit(stage, d)   { log.audit({ title: 'FV_AutoLot_SL:' + stage, details: fmt(d) }); }
    function errLog(stage, e)  { log.error({ title: 'FV_AutoLot_SL:' + stage, details: (e && e.stack) || (e && e.message) || fmt(e) }); }

    /* ------------------------------------------------------------------ *
     *  CACHES (per-request)                                               *
     * ------------------------------------------------------------------ */

    var lotItemCache    = {};
    var vendorCodeCache = {};

    /* ================================================================== *
     *  ENTRY POINT                                                        *
     * ================================================================== */

    function onRequest(context) {
        var params = context.request.parameters;
        var poId = params.poid;

        audit('onRequest', { method: context.request.method, poId: poId });

        // ── Validate input ──────────────────────────────────────────────
        if (!poId) {
            showError(context, 'Missing Parameter',
                'No Purchase Order ID was supplied (poid). ' +
                'Please use the "Receive with Auto-Lot" button on a Purchase Order.');
            return;
        }

        try {
            // ── 1. Transform PO → Item Receipt ──────────────────────────
            audit('transform.start', { poId: poId });

            var irRec = record.transform({
                fromType: record.Type.PURCHASE_ORDER,
                fromId:   parseInt(poId, 10),
                toType:   record.Type.ITEM_RECEIPT,
                isDynamic: false
            });

            var lineCount = irRec.getLineCount({ sublistId: ITEM_SUBLIST });
            audit('transform.done', { lines: lineCount });

            // ── 2. Get vendor from the receipt ──────────────────────────
            var vendorId = irRec.getValue('entity');
            audit('vendor', vendorId);

            if (!vendorId) {
                showError(context, 'No Vendor',
                    'The Item Receipt has no vendor. Cannot look up lot mappings.', poId);
                return;
            }

            // ── 2b. Build PO quantity fallback map ──────────────────────
            //    record.transform() often leaves 'quantity' as 0 on IR
            //    lines. Load the source PO and read quantityremaining.
            var poQtyMap = buildPoQuantityMap(parseInt(poId, 10));
            dbg('poQtyMap', poQtyMap);

            // ── 3. Mark lines for receiving + populate inventory detail ──
            var missing = [];
            var populated = 0;

            for (var i = 0; i < lineCount; i++) {
                var itemId = irRec.getSublistValue({ sublistId: ITEM_SUBLIST, fieldId: 'item', line: i });
                if (!itemId) continue;

                // Mark line for receiving
                irRec.setSublistValue({
                    sublistId: ITEM_SUBLIST,
                    fieldId:   'itemreceive',
                    line:      i,
                    value:     true
                });

                // Skip non-lot items
                if (!isLotNumbered(itemId)) {
                    dbg('line[' + i + '].skipNonLot', itemId);
                    continue;
                }

                // Get quantity — try receipt line, fall back to PO
                var quantity = parseFloat(
                    irRec.getSublistValue({ sublistId: ITEM_SUBLIST, fieldId: 'quantity', line: i })
                ) || 0;
                dbg('line[' + i + '].irQty', quantity);

                if (quantity <= 0) {
                    quantity = getPoQuantity(poQtyMap, itemId);
                    dbg('line[' + i + '].poFallbackQty', quantity);
                }

                if (quantity <= 0) {
                    dbg('line[' + i + '].skipZeroQty', itemId);
                    continue;
                }

                // Set the quantity on the receipt line so the saved
                // record reflects the correct amount
                irRec.setSublistValue({
                    sublistId: ITEM_SUBLIST,
                    fieldId:   'quantity',
                    line:      i,
                    value:     quantity
                });
                dbg('line[' + i + '].qtySet', quantity);

                // Look up vendor code
                var vendorCode = lookupVendorCode(vendorId, itemId);
                dbg('line[' + i + '].vendorCode', vendorCode);

                if (!vendorCode) {
                    var itemName = irRec.getSublistText({ sublistId: ITEM_SUBLIST, fieldId: 'item', line: i });
                    missing.push('Line ' + (i + 1) + ': ' + itemName);
                    audit('line[' + i + '].missingMapping', itemName);
                    continue;
                }

                // ── Populate inventory detail subrecord ─────────────────
                populateInventoryDetail(irRec, i, vendorCode, quantity);
                populated++;
                audit('line[' + i + '].done', { item: itemId, lot: vendorCode, qty: quantity });
            }

            audit('lotAssignment.summary', { populated: populated, missing: missing.length });

            // ── 4. Block save if any mappings are missing ────────────────
            if (missing.length) {
                showError(context, 'Missing Vendor Part Number Mapping',
                    'This receipt cannot be created. No active Vendor Part ' +
                    'Number mapping exists for:\n\n' + missing.join('\n') +
                    '\n\nCreate the mapping(s) on the custom record and try again.',
                    poId);
                return;
            }

            // ── 5. Save ─────────────────────────────────────────────────
            var irId = irRec.save({
                enableSourcing:        true,
                ignoreMandatoryFields: true
            });

            audit('save.success', { irId: irId });

            // ── 6. Redirect to the new Item Receipt ─────────────────────
            redirect.toRecord({
                type: record.Type.ITEM_RECEIPT,
                id:   irId
            });

        } catch (e) {
            errLog('onRequest.error', e);
            var userMessage = (e && e.message) || 'An unexpected error occurred while creating the Item Receipt.';
            showError(context, 'Auto-Lot Receipt Failed', userMessage, poId);
        }
    }

    /* ------------------------------------------------------------------ *
     *  INVENTORY DETAIL WRITE                                             *
     * ------------------------------------------------------------------ */

    function populateInventoryDetail(rec, line, vendorCode, quantity) {
        var invDetail = rec.getSublistSubrecord({
            sublistId: ITEM_SUBLIST,
            fieldId:   INV_DETAIL,
            line:      line
        });

        if (!invDetail) {
            throw error.create({
                name:    'FV_NO_INV_DETAIL_SUBRECORD',
                message: 'Inventory Detail subrecord unavailable on line ' + (line + 1) + '.'
            });
        }

        var count = invDetail.getLineCount({ sublistId: INV_ASSIGN });
        dbg('populate.existing', { line: line, count: count });

        // Clear extra assignment lines, keep line 0
        for (var j = count - 1; j >= 1; j--) {
            invDetail.removeLine({ sublistId: INV_ASSIGN, line: j });
        }
        if (count === 0) {
            invDetail.insertLine({ sublistId: INV_ASSIGN, line: 0 });
        }

        invDetail.setSublistValue({ sublistId: INV_ASSIGN, fieldId: 'receiptinventorynumber', line: 0, value: vendorCode });
        invDetail.setSublistValue({ sublistId: INV_ASSIGN, fieldId: 'quantity',               line: 0, value: quantity });
       // Set bin — try/catch individually so we see exactly if/why it fails
        try {
            invDetail.setSublistValue({ sublistId: INV_ASSIGN, fieldId: 'binnumber', line: 0, value: DEFAULT_BIN_ID });
            var binAfter = invDetail.getSublistValue({ sublistId: INV_ASSIGN, fieldId: 'binnumber', line: 0 });
            dbg('populate.setBin', { line: line, requested: DEFAULT_BIN_ID, actual: binAfter, stuck: (String(binAfter) === String(DEFAULT_BIN_ID)) });
        } catch (eBin) {
            errLog('populate.setBin.FAILED', eBin);
        }
      
        invDetail.setSublistValue({ sublistId: INV_ASSIGN, fieldId: 'inventorystatus',        line: 0, value: DEFAULT_INV_STATUS_ID });

        dbg('populate.done', { line: line, assignmentsNow: invDetail.getLineCount({ sublistId: INV_ASSIGN }) });
    }

    /* ------------------------------------------------------------------ *
     *  PO QUANTITY FALLBACK                                               *
     * ------------------------------------------------------------------ */

    /**
     * Loads the source PO and builds a map of { itemId: [qty, qty, …] }.
     * Uses quantityremaining first, falls back to quantity.
     */
    function buildPoQuantityMap(poId) {
        var qtyMap = {};
        if (!poId) return qtyMap;

        try {
            var poRec = record.load({
                type:      record.Type.PURCHASE_ORDER,
                id:        poId,
                isDynamic: false
            });

            var lc = poRec.getLineCount({ sublistId: 'item' });
            dbg('poQtyMap.lines', lc);

            for (var i = 0; i < lc; i++) {
                var itemId = String(poRec.getSublistValue({ sublistId: 'item', fieldId: 'item', line: i }));

                var qtyRemaining = parseFloat(
                    poRec.getSublistValue({ sublistId: 'item', fieldId: 'quantityremaining', line: i })
                ) || 0;

                var qtyOrdered = parseFloat(
                    poRec.getSublistValue({ sublistId: 'item', fieldId: 'quantity', line: i })
                ) || 0;

                var qty = qtyRemaining > 0 ? qtyRemaining : qtyOrdered;

                if (!qtyMap[itemId]) qtyMap[itemId] = [];
                qtyMap[itemId].push(qty);

                dbg('poQtyMap.line', { line: i, item: itemId, qtyRemaining: qtyRemaining, qtyOrdered: qtyOrdered, using: qty });
            }
        } catch (e) {
            errLog('buildPoQuantityMap', e);
        }

        return qtyMap;
    }

    /**
     * Pull next quantity for an item from the PO map (consumes in order).
     */
    function getPoQuantity(poQtyMap, itemId) {
        var key = String(itemId);
        if (!poQtyMap[key] || poQtyMap[key].length === 0) return 0;
        return poQtyMap[key].shift();
    }

    /* ------------------------------------------------------------------ *
     *  HELPERS                                                            *
     * ------------------------------------------------------------------ */

    function isLotNumbered(itemId) {
        var key = String(itemId);
        if (lotItemCache.hasOwnProperty(key)) return lotItemCache[key];
        var isLot = false;
        try {
            var f = search.lookupFields({ type: search.Type.ITEM, id: itemId, columns: ['islotitem'] });
            isLot = f.islotitem === true || f.islotitem === 'T';
        } catch (e) { errLog('isLotNumbered[' + key + ']', e); }
        lotItemCache[key] = isLot;
        return isLot;
    }

    function lookupVendorCode(vendorId, itemId) {
        var key = vendorId + '|' + itemId;
        if (vendorCodeCache.hasOwnProperty(key)) return vendorCodeCache[key];

        var filters = [
            [VPN_CODE, 'anyof', vendorId],
            'AND',
            [VPN_ITEM,   'anyof', itemId],
            'AND',
            ['isinactive', 'is', 'F']
        ];
        dbg('vendorCode.search', { vendor: vendorId, item: itemId });

        var code = null;
        try {
            var s = search.create({ type: VENDOR_PART_NUM_RECORD, filters: filters, columns: [VPN_VENDOR] });
            s.run().each(function (r) { code = r.getValue(VPN_VENDOR); return false; });
            vendorCodeCache[key] = code;
        } catch (e) { errLog('vendorCode', e); }

        return code;
    }

    /* ------------------------------------------------------------------ *
     *  ERROR PAGE                                                         *
     * ------------------------------------------------------------------ */

    function showError(context, title, message, poId) {
        var form = serverWidget.createForm({ title: 'Receive with Auto-Lot' });

        var msgField = form.addField({
            id:    'custpage_error_msg',
            type:  serverWidget.FieldType.INLINEHTML,
            label: 'Error'
        });

        msgField.defaultValue =
            '<div style="margin:20px 0;">' +
                '<h2 style="color:#c0392b;">' + escapeHtml(title) + '</h2>' +
                '<p style="font-size:14px; white-space:pre-wrap;">' + escapeHtml(message) + '</p>' +
            '</div>';

        if (poId) {
            form.addButton({
                id:           'custpage_btn_back',
                label:        'Back to Purchase Order',
                functionName: 'window.location.href="/app/accounting/transactions/purchord.nl?id=' + parseInt(poId, 10) + '"'
            });
        }

        context.response.writePage(form);
    }

    function escapeHtml(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    return {
        onRequest: onRequest
    };
});
