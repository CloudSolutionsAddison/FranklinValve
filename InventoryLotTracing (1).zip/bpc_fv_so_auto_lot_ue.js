/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 *
 * Franklin Valve — Sales Order Auto Lot Assignment
 *
 * beforeSubmit: for every lot-numbered item line on a Sales Order,
 * automatically select and assign inventory lots using the shared
 * FV lot-selection algorithm.
 *
 * Lines flagged "Create WO" are skipped — those will be fulfilled
 * by a future Work Order, not from existing inventory.
 *
 * Serialized assembly items are explicitly skipped — serial selection
 * is entirely manual and outside the scope of this automation.
 *
 * Only COMPLETE quantity fulfilment triggers inventory-detail
 * population.  Partial stock coverage leaves the detail blank so
 * lot / serial selection is deferred to fulfilment.
 *
 * On edit, the script re-evaluates every qualifying line against the
 * current ordered quantity.  If lots can no longer cover the full
 * quantity the existing inventory detail is cleared.
 *
 * Functional Design Ref: Franklin Valve Inv Lot Traceability FDD v0.3
 *
 * @module fv_so_auto_lot_ue
 */
define([
    'N/log',
    'N/runtime',
    './bpc_fv_auto_lot_util'
], function (log, runtime, lotUtil) {

    /**
     * beforeSubmit — Auto-assign lots on Sales Order item lines.
     *
     * @param {Object} context
     * @param {Record} context.newRecord
     * @param {string} context.type  - create | edit | …
     */
    function beforeSubmit(context) {
        var triggerType = context.type;

        if (triggerType !== context.UserEventType.CREATE &&
            triggerType !== context.UserEventType.EDIT) {
            return;
        }

        var rec       = context.newRecord;
        var lineCount = rec.getLineCount({ sublistId: 'item' });

        log.debug('fv_so_auto_lot_ue:beforeSubmit',
            'Processing SO ' + rec.id + ' | lines=' + lineCount +
            ' | trigger=' + triggerType);

        for (var i = 0; i < lineCount; i++) {

            /* ── 1. Skip lines where Create WO is checked ── */
            var createWO = rec.getSublistValue({
                sublistId: 'item',
                fieldId:   'createwo',
                line:      i
            });

            if (createWO === true || createWO === 'T') {
                log.debug('fv_so_auto_lot_ue',
                    'Line ' + i + ': Create WO is on — skipping');
                continue;
            }
            // Fallback: also check the dedicated linked-WO field.
            // If createwo cleared to false/empty after WO creation, this catches it.
            // NOTE: verify 'createdwo' field ID in your account's Records Browser
            //       (Customization > Scripting > Records Browser > Sales Order > item sublist).
            //       Common alternatives: 'woid', or a custom field.
            // var linkedWO = rec.getSublistValue({
            //     sublistId: 'item',
            //     fieldId:   'createdwo',
            //     line:      i
            // });

            // if (linkedWO) {
            //     log.debug('fv_so_auto_lot_ue',
            //         'Line ' + i + ': Linked WO ' + linkedWO + ' found — skipping');
            //     continue;
            // }


            /* ── 2. Get item ID ── */
            var itemId = rec.getSublistValue({
                sublistId: 'item',
                fieldId:   'item',
                line:      i
            });

            if (!itemId) { continue; }

            /* ── 2a. Skip serialized assembly items ── */
            try {
                if (lotUtil.isSerializedAssembly(itemId)) {
                    log.debug('fv_so_auto_lot_ue',
                        'Line ' + i + ': item ' + itemId +
                        ' is a serialized assembly — skipping (manual serial selection)');
                    continue;
                }
            } catch (e) {
                log.debug('fv_so_auto_lot_ue',
                    'Line ' + i + ': item ' + itemId +
                    ' serialized-assembly check error (' + e.name + ') — continuing');
            }

            /* ── 2b. Check if lot-numbered ── */
            var isLot;
            try {
                isLot = lotUtil.isLotNumbered(itemId);
            } catch (e) {
                log.debug('fv_so_auto_lot_ue',
                    'Line ' + i + ': item ' + itemId +
                    ' not lot-checkable (' + e.name + ')');
                continue;
            }

            if (!isLot) {
                log.debug('fv_so_auto_lot_ue',
                    'Line ' + i + ': item ' + itemId +
                    ' is not lot-numbered — skipping');
                continue;
            }

            /* ── 3. Read quantity and location ── */
            var quantity = parseFloat(rec.getSublistValue({
                sublistId: 'item',
                fieldId:   'quantity',
                line:      i
            })) || 0;

            if (quantity <= 0) { continue; }

            // Start - AA: 8-25: If the line has a location, use that; otherwise, use the header location.
            var lineLocationId = rec.getSublistValue({
                sublistId: 'item',
                fieldId:   'location',
                line:      i
            });

            var locationId = lineLocationId || rec.getValue({ fieldId: 'location' });

            if (!locationId) {
                log.audit('fv_so_auto_lot_ue',
                    'Line ' + i + ': item ' + itemId +
                    ' — no location resolved (line or header) — skipping');
                continue;
            }
            // End - AA


            /* ── 4. Look up available lots ── */
            var availableLots = lotUtil.getAvailableLots(itemId, locationId);

            if (!availableLots || availableLots.length === 0) {
                log.audit('fv_so_auto_lot_ue',
                    'Line ' + i + ': item ' + itemId +
                    ' — no lots available at location ' + locationId +
                    ' — inventory detail left blank (deferred to fulfilment)');

                /* On edit the line may carry stale detail from the
                   previous save — clear it so the detail stays blank. */
                _safeClearDetail(rec, i, itemId);
                continue;
            }

            /* ── 5. Run lot-selection algorithm ── */
            var selection = lotUtil.selectLotsGreedyMax(availableLots, quantity);

            if (!selection.success) {
                /*
                 * PARTIAL FULFILMENT IS NOT ALLOWED.
                 * If the available stock cannot cover the ENTIRE ordered
                 * quantity the inventory detail must remain blank.
                 * Lot selection is deferred to fulfilment where the
                 * client will manually pick the lot(s).
                 */
                log.audit('fv_so_auto_lot_ue',
                    'Line ' + i + ': item ' + itemId +
                    ' — shortfall of ' + selection.shortfall +
                    ' at location ' + locationId +
                    ' — inventory detail left blank (deferred to fulfilment)');

                /* Clear any stale detail that may exist from a prior save
                   (e.g. user increased qty on edit beyond available stock). */
                _safeClearDetail(rec, i, itemId);
                continue;
            }

            /* ── 6. Write inventory detail ── */
            try {
                lotUtil.writeInventoryDetail(rec, 'item', i, selection.lines);

                log.debug('fv_so_auto_lot_ue',
                    'Line ' + i + ': assigned ' + selection.lines.length +
                    ' lot(s) for qty ' + quantity);
            } catch (e) {
                log.error('fv_so_auto_lot_ue',
                    'Line ' + i + ': writeInventoryDetail failed — ' +
                    e.name + ': ' + e.message);
            }
        }
    }

    /* ------------------------------------------------------------------ *
     *  PRIVATE HELPERS                                                    *
     * ------------------------------------------------------------------ */

    /**
     * Attempt to clear existing inventory detail on a line.
     * Swallows errors so it never blocks the save.
     *
     * @param {Record} rec
     * @param {number} lineIdx
     * @param {number|string} itemId  - For logging only
     */
    function _safeClearDetail(rec, lineIdx, itemId) {
        try {
            lotUtil.clearInventoryDetail(rec, 'item', lineIdx);
            log.debug('fv_so_auto_lot_ue',
                'Line ' + lineIdx + ': cleared existing inventory detail for item ' + itemId);
        } catch (e) {
            /* Not every line will have an openable inventory detail
               subrecord (e.g. first create, or non-lot items that
               slipped through).  This is expected — do not escalate. */
            log.debug('fv_so_auto_lot_ue',
                'Line ' + lineIdx + ': clearInventoryDetail skipped — ' + e.message);
        }
    }

    return {
        beforeSubmit: beforeSubmit
    };
});
