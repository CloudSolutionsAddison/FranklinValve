/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 *
 * Franklin Valve — Auto Lot Suitelet (JSON endpoint)
 *
 * Called by the Assembly Build client script at save-time.
 * Accepts a POST with an array of component lines, runs the shared
 * lot-selection algorithm for each lot-tracked item, and returns the
 * selections as JSON so the client script can write inventory detail
 * before NetSuite's native validation fires.
 *
 * Functional Design Ref: FDD v0.3, Section 1.2 (FR-09)
 */
define([
    'N/log',
    './bpc_fv_auto_lot_util'
], function (log, util) {

    var SCRIPT_ID = 'FV_AutoLot_SL';

    /**
     * @param {Object} context
     * @param {ServerRequest}  context.request
     * @param {ServerResponse} context.response
     */
    function onRequest(context) {

        if (context.request.method !== 'POST') {
            context.response.setHeader({ name: 'Content-Type', value: 'application/json' });
            context.response.write(JSON.stringify({ error: 'POST required' }));
            return;
        }

        try {
            var body = JSON.parse(context.request.body);
            var lines = body.lines || [];
            log.debug(SCRIPT_ID + ' | Request', 'Received ' + lines.length + ' component line(s)');

            var results = [];

            for (var i = 0; i < lines.length; i++) {
                var line = lines[i];

                // ── Skip non-lot-tracked items ──
                var isLot = false;
                try {
                    isLot = util.isLotNumbered(line.itemId);
                } catch (e) {
                    // Item type may not support islotitem (e.g. non-inventory)
                    log.debug(SCRIPT_ID + ' | isLotNumbered error',
                        'item=' + line.itemId + ' err=' + e.message);
                }

                if (!isLot) {
                    results.push({
                        line:         line.line,
                        isLotTracked: false
                    });
                    continue;
                }

                var qty = parseFloat(line.quantity) || 0;
                if (qty <= 0) {
                    results.push({
                        line:         line.line,
                        isLotTracked: true,
                        success:      true,
                        lots:         []
                    });
                    continue;
                }

                // ── Query available lots and run selection ──
                var availableLots = util.getAvailableLots(line.itemId, line.locationId);
                var selection     = util.selectLots(availableLots, qty);

                log.debug(SCRIPT_ID + ' | Line ' + line.line,
                    'item=' + line.itemId + ' qty=' + qty +
                    ' success=' + selection.success +
                    ' lots=' + selection.lines.length);

                results.push({
                    line:         line.line,
                    isLotTracked: true,
                    success:      selection.success,
                    lots:         selection.lines,      // [{lotNumber, lotId, qty}]
                    shortfall:    selection.shortfall
                });
            }

            context.response.setHeader({ name: 'Content-Type', value: 'application/json' });
            context.response.write(JSON.stringify({ results: results }));

        } catch (e) {
            log.error(SCRIPT_ID + ' | Error', e.message + '\n' + e.stack);
            context.response.setHeader({ name: 'Content-Type', value: 'application/json' });
            context.response.write(JSON.stringify({ error: e.message }));
        }
    }

    return {
        onRequest: onRequest
    };
});
