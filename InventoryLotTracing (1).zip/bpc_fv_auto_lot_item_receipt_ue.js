/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 *
 * Franklin Valve  — Auto Lot: Item Receipt (User Event Script)
 *
 * ============================================================================
 *  THE PROBLEM THIS VERSION IS FIGHTING
 * ============================================================================
 *  Item Receipt of a lot item shows a NATIVE, CLIENT-SIDE validation on save:
 *      "Please configure the inventory detail in line N of the item list."
 *  That alert returns false from the form's save validation, so the record
 *  never submits and beforeSubmit never runs. A client script cannot create
 *  the inventory-detail subrecord on this list sublist, so the check cannot
 *  be satisfied in the browser either.
 *
 *  Two entry points here:
 *    beforeLoad   - LONG SHOT. Pre-fills inventory detail when the receipt is
 *                   transformed from a PO, hoping the form loads already valid
 *                   so the native alert never fires. Subrecord edits in
 *                   beforeLoad frequently do NOT render into the interactive
 *                   inventory-detail popup, so this may not work. Never throws
 *                   (throwing in beforeLoad breaks the form load).
 *    beforeSubmit - Enforcement + write, for any save that DOES reach the
 *                   server (e.g. if beforeLoad rendered, or receipts created
 *                   server-side). Throws to block on missing vendor mapping.
 *
 *  If the alert still appears after deploying this, beforeLoad did not render
 *  and the receipt must be created + saved entirely server-side (Suitelet /
 *  button on the PO). The assignLots() logic below moves to that Suitelet
 *  unchanged.
 *
 * ============================================================================
 *  FIX: QUANTITY FALLBACK FROM SOURCE PO
 * ============================================================================
 *  During beforeLoad on a transformed Item Receipt, the 'quantity' field on
 *  sublist lines is often not yet populated (returns 0 or null). This version
 *  detects 'createdfrom', loads the source PO once, and builds a map of
 *  item → quantityremaining. When the receipt line quantity is 0, we fall
 *  back to that PO map.
 *
 * ============================================================================
 *  DEPLOYMENT
 * ============================================================================
 *  Applies To : Item Receipt
 *  Events     : beforeLoad + beforeSubmit (create context)
 *
 *  STILL TO CONFIRM (see prior troubleshooting):
 *    - DEFAULT_BIN_ID / DEFAULT_INV_STATUS_ID -> real internal IDs
 *    - VPN_VENDOR ('name' + 'anyof') is suspect; verify field & operator
 *    - VPN_CODE field ID
 *    - drop binnumber/inventorystatus if the item/location isn't bin-tracked
 *      or Inventory Status isn't enabled
 *
 * Functional Design Ref: FDD v0.3, Section 1.1
 */
define([
    'N/search',
    'N/record',
    'N/error',
    'N/log'
], function (search, record, error, log) {

    'use strict';

    /* ------------------------------------------------------------------ *
     *  CONSTANTS                                                          *
     * ------------------------------------------------------------------ */

    var ITEM_SUBLIST = 'item';
    var INV_DETAIL   = 'inventorydetail';
    var INV_ASSIGN   = 'inventoryassignment';

    var VENDOR_PART_NUM_RECORD = 'customrecord_bpc_fv_vpn';
    var VPN_VENDOR = 'name';                          // <-- verify
    var VPN_ITEM   = 'custrecord_bpc_fv_item';
    var VPN_CODE   = 'custrecord_bpc_ui_vendorlist';  // <-- verify

    // >>> REPLACE with the actual internal IDs from the target account <<<
    var DEFAULT_BIN_ID        = 4327;
    var DEFAULT_INV_STATUS_ID = 1;

    /* ------------------------------------------------------------------ *
     *  LOGGING                                                            *
     * ------------------------------------------------------------------ */

    var DEBUG = true;

    function fmt(d) {
        if (d === undefined || d === null) return '';
        return (typeof d === 'object') ? JSON.stringify(d) : String(d);
    }
    function dbg(stage, d)   { if (DEBUG) log.debug({ title: 'FV_AutoLot_UE:' + stage, details: fmt(d) }); }
    function audit(stage, d) { log.audit({ title: 'FV_AutoLot_UE:' + stage, details: fmt(d) }); }
    function err(stage, e)   { log.error({ title: 'FV_AutoLot_UE:' + stage, details: (e && e.stack) || (e && e.message) || fmt(e) }); }

    var lotItemCache    = {};
    var vendorCodeCache = {};

    /* ================================================================== *
     *  PO QUANTITY FALLBACK                                               *
     * ================================================================== */

    /**
     * Loads the source PO and builds a map of { itemId: quantityremaining }.
     * If a PO has multiple lines for the same item, values are stored as
     * an array so they can be consumed in order.
     *
     * @param {string|number} poId  Internal ID of the source Purchase Order
     * @returns {Object}            Map of itemId → [qty, qty, …]
     */
    function buildPoQuantityMap(poId) {
        var qtyMap = {};
        if (!poId) return qtyMap;

        try {
            var poRec = record.load({
                type: record.Type.PURCHASE_ORDER,
                id: poId,
                isDynamic: false
            });

            var lineCount = poRec.getLineCount({ sublistId: 'item' });
            dbg('buildPoQuantityMap.lines', lineCount);

            for (var i = 0; i < lineCount; i++) {
                var itemId = String(poRec.getSublistValue({ sublistId: 'item', fieldId: 'item', line: i }));

                // quantityremaining = open qty still to receive
                var qtyRemaining = parseFloat(
                    poRec.getSublistValue({ sublistId: 'item', fieldId: 'quantityremaining', line: i })
                ) || 0;

                // Also grab the full quantity as a second fallback
                var qtyOrdered = parseFloat(
                    poRec.getSublistValue({ sublistId: 'item', fieldId: 'quantity', line: i })
                ) || 0;

                var qty = qtyRemaining > 0 ? qtyRemaining : qtyOrdered;

                if (!qtyMap[itemId]) {
                    qtyMap[itemId] = [];
                }
                qtyMap[itemId].push(qty);

                dbg('buildPoQuantityMap.line', { line: i, item: itemId, qtyRemaining: qtyRemaining, qtyOrdered: qtyOrdered, using: qty });
            }
        } catch (e) {
            err('buildPoQuantityMap', e);
        }

        return qtyMap;
    }

    /**
     * Pull the next available quantity for an item from the PO map.
     * Consumes entries in order so multiple PO lines for the same item
     * are matched to receipt lines sequentially.
     *
     * @param {Object}        poQtyMap  Map built by buildPoQuantityMap
     * @param {string|number} itemId    Item internal ID
     * @returns {number}                Quantity (0 if not found)
     */
    function getPoQuantity(poQtyMap, itemId) {
        var key = String(itemId);
        if (!poQtyMap[key] || poQtyMap[key].length === 0) return 0;
        return poQtyMap[key].shift();   // consume first entry
    }

    /* ================================================================== *
     *  ENTRY POINT — beforeLoad (long shot: pre-fill so the form is valid)*
     * ================================================================== */

    function beforeLoad(context) {
        if (context.type !== context.UserEventType.CREATE) return;
        audit('beforeLoad.enter', { type: context.type });
        try {
            // dryRun = true  →  validate mappings / log, but do NOT touch
            // the inventory-detail subrecord.  getSublistSubrecord is not
            // available during beforeLoad on a transformed record.
            var res = assignLots(context.newRecord, /* dryRun */ true);
            audit('beforeLoad.result', res);
        } catch (e) {
            // NEVER rethrow here — an error in beforeLoad breaks the form load.
            err('beforeLoad', e);
        }
    }

    /* ================================================================== *
     *  ENTRY POINT — beforeSubmit (write + hard block)                    *
     * ================================================================== */

    function beforeSubmit(context) {
        if (context.type !== context.UserEventType.CREATE) return;
        audit('beforeSubmit.enter', { id: context.newRecord.id, type: context.type });

        var res = assignLots(context.newRecord, /* dryRun */ false);
        audit('beforeSubmit.summary', res);

        if (res.missing.length) {
            throw error.create({
                name:      'FV_MISSING_VENDOR_MAPPING',
                message:   'This receipt cannot be saved. No active Vendor Part ' +
                           'Number mapping exists for:\n\n' + res.missing.join('\n') +
                           '\n\nCreate the mapping(s) and try again.',
                notifyOff: true
            });
        }
    }

    /* ------------------------------------------------------------------ *
     *  SHARED WORK — iterate lines, populate detail, collect missing      *
     * ------------------------------------------------------------------ */

    function assignLots(rec, dryRun) {
        var vendorId = rec.getValue('entity');
        if (!vendorId) { dbg('assignLots.skip', 'no vendor'); return { missing: [], populated: 0 }; }

        dbg('assignLots.mode', dryRun ? 'DRY RUN (beforeLoad)' : 'LIVE (beforeSubmit)');

        // ── Build PO quantity fallback map ──────────────────────────────
        var poId = rec.getValue('createdfrom');
        var poQtyMap = {};
        if (poId) {
            dbg('assignLots.sourcePO', poId);
            poQtyMap = buildPoQuantityMap(poId);
            dbg('assignLots.poQtyMap', poQtyMap);
        }

        var lineCount = rec.getLineCount({ sublistId: ITEM_SUBLIST });
        dbg('assignLots.lineCount', lineCount);

        var missing = [];
        var populated = 0;

        for (var i = 0; i < lineCount; i++) {
            try {
                var r = processLine(rec, i, vendorId, poQtyMap, dryRun);
                if (r && r.missing) missing.push(r.missing);
                else if (r && r.populated) populated++;
            } catch (e) {
                err('assignLots.line[' + i + ']', e);
                throw e;   // a broken write must surface, not silently receive
            }
        }
        return { missing: missing, populated: populated };
    }

    function processLine(rec, line, vendorId, poQtyMap, dryRun) {
        var itemId = rec.getSublistValue({ sublistId: ITEM_SUBLIST, fieldId: 'item', line: line });
        dbg('processLine.itemId', itemId);

        if (!itemId) return null;

        var isReceiving = rec.getSublistValue({ sublistId: ITEM_SUBLIST, fieldId: 'itemreceive', line: line });
        dbg('processLine.isReceiving', isReceiving);
        //TBD: if (isReceiving === false) return null;

        if (!isLotNumbered(itemId)) return null;

        // ── Quantity: try the receipt line first, fall back to PO ────────
        var quantity = parseFloat(
            rec.getSublistValue({ sublistId: ITEM_SUBLIST, fieldId: 'quantity', line: line })
        ) || 0;

        if (quantity <= 0) {
            quantity = getPoQuantity(poQtyMap, itemId);
            dbg('processLine.qtyFallbackFromPO', { line: line, item: itemId, poQty: quantity });
        }

        dbg('processLine.qty', quantity);
        //TBD: if (quantity <= 0) return null;

        var vendorCode = lookupVendorCode(vendorId, itemId);
        dbg('processLine.vendorCode', vendorCode);
        if (!vendorCode) {
            var itemName = rec.getSublistText({ sublistId: ITEM_SUBLIST, fieldId: 'item', line: line });
            audit('processLine.missingMapping', { line: line, item: itemName });
            return { missing: 'Line ' + (line + 1) + ': ' + itemName };
        }

        // ── dryRun: log what WOULD happen, but skip the subrecord write.
        //    getSublistSubrecord is not available during beforeLoad on a
        //    transformed record — it throws.
        if (dryRun) {
            audit('processLine.dryRun', { line: line, item: itemId, lot: vendorCode, qty: quantity, msg: 'Would populate — skipping subrecord write in beforeLoad' });
            return { populated: true };
        }

        populateInventoryDetail(rec, line, vendorCode, quantity);
        audit('processLine.done', { line: line, item: itemId, lot: vendorCode, qty: quantity });
        return { populated: true };
    }

    /* ------------------------------------------------------------------ *
     *  INVENTORY DETAIL WRITE (server-side standard mode)                *
     * ------------------------------------------------------------------ */

    function populateInventoryDetail(rec, line, vendorCode, quantity) {
        var invDetail = rec.getSublistSubrecord({ sublistId: ITEM_SUBLIST, fieldId: INV_DETAIL, line: line });
        if (!invDetail) {
            throw error.create({ name: 'FV_NO_INV_DETAIL_SUBRECORD', message: 'Inventory Detail subrecord unavailable on line ' + line + '.' });
        }

        var count = invDetail.getLineCount({ sublistId: INV_ASSIGN });
        dbg('populate.existingAssignments', { line: line, count: count });

        for (var j = count - 1; j >= 1; j--) {
            invDetail.removeLine({ sublistId: INV_ASSIGN, line: j });
        }
        if (count === 0) {
            invDetail.insertLine({ sublistId: INV_ASSIGN, line: 0 });
        }

        invDetail.setSublistValue({ sublistId: INV_ASSIGN, fieldId: 'receiptinventorynumber', line: 0, value: vendorCode });
        invDetail.setSublistValue({ sublistId: INV_ASSIGN, fieldId: 'quantity',               line: 0, value: quantity });
        //invDetail.setSublistValue({ sublistId: INV_ASSIGN, fieldId: 'binnumber',              line: 0, value: DEFAULT_BIN_ID });
        invDetail.setSublistValue({ sublistId: INV_ASSIGN, fieldId: 'inventorystatus',        line: 0, value: DEFAULT_INV_STATUS_ID });

        dbg('populate.committed', { line: line, assignmentsNow: invDetail.getLineCount({ sublistId: INV_ASSIGN }) });
    }

    /* ------------------------------------------------------------------ *
     *  HELPERS                                                           *
     * ------------------------------------------------------------------ */

    function isLotNumbered(itemId) {
        var key = String(itemId);
        if (lotItemCache.hasOwnProperty(key)) return lotItemCache[key];
        var isLot = false;
        try {
            var f = search.lookupFields({ type: search.Type.ITEM, id: itemId, columns: ['islotitem'] });
            isLot = f.islotitem === true || f.islotitem === 'T';
        } catch (e) { err('isLotNumbered[' + key + ']', e); }
        lotItemCache[key] = isLot;
        return isLot;
    }

    function lookupVendorCode(vendorId, itemId) {
        var key = vendorId + '|' + itemId;
        if (vendorCodeCache.hasOwnProperty(key)) return vendorCodeCache[key];

        var filters = [
            [VPN_CODE, 'anyof', vendorId],   // <-- verify field/operator
            'AND',
            [VPN_ITEM,   'anyof', itemId],
            'AND',
            ['isinactive', 'is', 'F']
        ];
        dbg('vendorCode.config', { record: VENDOR_PART_NUM_RECORD, vendorField: VPN_VENDOR, itemField: VPN_ITEM, codeField: VPN_CODE });

        var code = null, s;
        try {
            s = search.create({ type: VENDOR_PART_NUM_RECORD, filters: filters, columns: [VPN_VENDOR] });
        } catch (eCreate) { err('vendorCode.create', eCreate); return null; }

        try {
            s.run().each(function (r) { code = r.getValue(VPN_VENDOR); return false; });
            vendorCodeCache[key] = code;
        } catch (eRun) { err('vendorCode.run', eRun); }

        return code;
    }

    return {
        beforeLoad:   beforeLoad,
        beforeSubmit: beforeSubmit
    };
});
