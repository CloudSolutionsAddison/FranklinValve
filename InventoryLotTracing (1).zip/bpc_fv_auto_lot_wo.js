/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 *
 * Franklin Valve — Auto Lot: Work Order Components
 *
 * afterSubmit on the Work Order record.  After the WO is saved, this
 * script reloads it in DYNAMIC MODE and writes inventory detail for
 * every lot-tracked component line using the lowest-bin-quantity
 * selection algorithm.
 *
 * Why afterSubmit + dynamic reload?
 * ─────────────────────────────────
 * In beforeSubmit, context.newRecord is in standard mode.  Standard-mode
 * subrecord writes (getSublistSubrecord / setSublistValue) execute
 * without error but are silently discarded by NetSuite on the Work Order.
 * The UI persists inventory detail because it operates in dynamic mode.
 * By reloading the saved WO in dynamic mode in afterSubmit, we match the
 * same code path the UI uses.
 *
 * Behaviour by scenario:
 *
 *   COMPLETE QTY AVAILABLE   — Inventory Detail is auto-populated
 *                               using lowest-bin-quantity logic.
 *
 *   NO / PARTIAL QTY         — Inventory Detail is left blank.
 *                               The WO save is NEVER blocked.
 *                               The client will manually populate it
 *                               once stock becomes available.
 *
 *   MIXED COMPONENTS         — Only the components with full stock
 *                               are assigned; the rest are left blank.
 *
 *   ALREADY-CONFIGURED LINES — Lines whose Inventory Detail was
 *                               written on a prior save (by this
 *                               script or by the user) are never
 *                               overwritten or re-processed.
 *
 *   SERIALIZED ASSEMBLIES    — Skipped entirely; serial selection is
 *                               manual and outside this automation.
 *
 *   LOT REJECTED BY ENGINE   — If NetSuite's commit engine rejects a
 *                               lot assignment (e.g. the assignable
 *                               quantity is lower than InventoryBalance
 *                               reports), the script parses the actual
 *                               available qty from the error, writes
 *                               that reduced amount, and spills the
 *                               deficit to the next available lot(s).
 *                               If the total written still falls short,
 *                               the component is deferred rather than
 *                               throwing a USER_ERROR.
 *
 * Functional Design Ref: FDD v0.3, Section 1.2 (FR-09)
 *
 * @module bpc_fv_auto_lot_wo
 */
define([
    'N/record',
    'N/log',
    'N/error',
    './bpc_fv_auto_lot_util'
], function (record, log, error, util) {

    var SCRIPT_ID = 'FV_AutoLot_WO';

    /* Commit-policy value for "Do Not Commit" on a WO component line.
       Kept as a named constant for the (optional) Fix 2 lever below. */
    var COMMIT_DO_NOT = 3;

    /**
     * Attempt to write a single inventory-assignment line on the
     * Inventory Detail subrecord.  If the commit engine rejects the
     * requested qty (e.g. "You only have 7 available"), parse the
     * actual limit and retry once at the reduced qty.
     *
     * @param {Subrecord} invDetail  – inventorydetail subrecord (dynamic)
     * @param {string}    lotId      – internal ID of the lot
     * @param {number}    desiredQty – qty we want to assign
     * @param {string}    lineLabel  – e.g. "Line 19" for logging
     * @returns {number}  qty actually written (0 if fully rejected)
     */
    function tryWriteLot(invDetail, lotId, desiredQty, lineLabel) {

        /* ── First attempt at full qty ── */
        try {
            invDetail.selectNewLine({ sublistId: 'inventoryassignment' });
            invDetail.setCurrentSublistValue({
                sublistId: 'inventoryassignment',
                fieldId:   'issueinventorynumber',
                value:     lotId
            });
            invDetail.setCurrentSublistValue({
                sublistId: 'inventoryassignment',
                fieldId:   'quantity',
                value:     desiredQty
            });
            invDetail.commitLine({ sublistId: 'inventoryassignment' });
            return desiredQty;
        } catch (err) {
            /* Cancel the failed new line so the subrecord is clean */
            try { invDetail.cancelLine({ sublistId: 'inventoryassignment' }); }
            catch (ignore) { /* no pending line — safe to ignore */ }

            /* Parse the actual assignable qty from the error message.
             * Expected: "You only have 7 available. Please enter …" */
            var match = err.message.match(/You only have (\d+\.?\d*) available/i);
            var actualQty = match ? parseFloat(match[1]) : 0;

            if (actualQty <= 0) {
                log.audit(SCRIPT_ID + ' | ' + lineLabel,
                    'Lot ' + lotId + ' rejected entirely (' +
                    err.name + ': ' + err.message + '). Skipping lot.');
                return 0;
            }

            log.audit(SCRIPT_ID + ' | ' + lineLabel,
                'Lot ' + lotId + ' capped at ' + actualQty +
                ' (requested ' + desiredQty + '). Writing reduced qty.');

            /* ── Second attempt at reduced qty ── */
            try {
                invDetail.selectNewLine({ sublistId: 'inventoryassignment' });
                invDetail.setCurrentSublistValue({
                    sublistId: 'inventoryassignment',
                    fieldId:   'issueinventorynumber',
                    value:     lotId
                });
                invDetail.setCurrentSublistValue({
                    sublistId: 'inventoryassignment',
                    fieldId:   'quantity',
                    value:     actualQty
                });
                invDetail.commitLine({ sublistId: 'inventoryassignment' });
                return actualQty;
            } catch (retryErr) {
                try { invDetail.cancelLine({ sublistId: 'inventoryassignment' }); }
                catch (ignore) { /* safe to ignore */ }
                log.audit(SCRIPT_ID + ' | ' + lineLabel,
                    'Lot ' + lotId + ' reduced-qty retry also failed (' +
                    retryErr.name + ': ' + retryErr.message + '). Skipping lot.');
                return 0;
            }
        }
    }

    /**
     * afterSubmit — fires after create / edit of Work Order.
     */
    function afterSubmit(context) {
        var triggerType = context.type;

        log.debug(SCRIPT_ID + ' | afterSubmit Entry',
            'Event type: ' + triggerType);

        if (triggerType !== context.UserEventType.CREATE &&
            triggerType !== context.UserEventType.EDIT) {
            return;
        }

        var woId = context.newRecord.id;
        log.debug(SCRIPT_ID + ' | WO ID', woId);

        /* ── Load the saved WO in dynamic mode ── */
        var rec = record.load({
            type:      record.Type.WORK_ORDER,
            id:        woId,
            isDynamic: true
        });

        var sublistId = 'item';
        var lineCount = rec.getLineCount({ sublistId: sublistId });
        log.debug(SCRIPT_ID + ' | Component Lines', 'Total: ' + lineCount);

        /* ── Capture header location as fallback for component lines ── */
        var headerLocation = rec.getValue({ fieldId: 'location' });
        log.debug(SCRIPT_ID + ' | Header Location', headerLocation);

        var assigned  = 0;   // lines where detail was written this pass
        var preserved = 0;   // lines already carrying detail (left alone)
        var deferred  = 0;   // lines left blank (no / partial stock / rejected)

        for (var i = 0; i < lineCount; i++) {

            /* ── Read item via non-editing accessor ── */
            var itemId = rec.getSublistValue({
                sublistId: sublistId,
                fieldId:   'item',
                line:      i
            });

            if (!itemId) { continue; }

            /* ── 1. Skip serialized assembly items ── */
            try {
                if (util.isSerializedAssembly(itemId)) {
                    log.debug(SCRIPT_ID + ' | Line ' + (i + 1),
                        'Item ' + itemId +
                        ' is a serialized assembly — skipping (manual serial selection).');
                    continue;
                }
            } catch (e) {
                log.debug(SCRIPT_ID + ' | Line ' + (i + 1),
                    'Serialized-assembly check error for item ' + itemId +
                    ' (' + e.name + ') — continuing.');
            }

            /* ── 2. Skip non-lot-numbered items ── */
            var isLot = false;
            try {
                isLot = util.isLotNumbered(itemId);
            } catch (e) {
                log.debug(SCRIPT_ID + ' | Line ' + (i + 1),
                    'Item ' + itemId +
                    ' not lot-checkable (' + e.name + '). Skipping.');
            }

            if (!isLot) {
                log.debug(SCRIPT_ID + ' | Line ' + (i + 1),
                    'Item ' + itemId + ' not lot-numbered. Skipping.');
                continue;
            }

            /* ── 3. Read quantity ── */
            var quantity = parseFloat(rec.getSublistValue({
                sublistId: sublistId,
                fieldId:   'quantity',
                line:      i
            })) || 0;

            if (quantity <= 0) { continue; }

            /* ── 4. Read location (fall back to WO header location) ── */
            var locationId = rec.getSublistValue({
                sublistId: sublistId,
                fieldId:   'location',
                line:      i
            }) || headerLocation;

            log.debug(SCRIPT_ID + ' | Line ' + (i + 1) + ' Processing',
                'Item: ' + itemId + ' | Qty: ' + quantity +
                ' | Location: ' + locationId);

            /* ── 5. Select the line for dynamic-mode subrecord access ── */
            rec.selectLine({ sublistId: sublistId, line: i });

            /* ── 5-DIAG. Commitment diagnostic ──
             * Root-cause probe for the "You only have N available" error.
             * If the line is already committed here (before we touch
             * inventory detail), the WO's own auto-commit has reserved
             * units against a lot, which is why the assignable qty the
             * commit engine enforces is LOWER than the InventoryBalance
             * snapshot that getAvailableLots reads.
             *
             * Interpreting the output:
             *   committed qty  > 0                → WO auto-commit is holding stock (see Fix 2)
             *   commit policy == 1 (Available Qty)→ line auto-commits; competes with our assignment
             *   commit policy == 3 (Do Not Commit)→ no competing reservation
             * Remove or downgrade this log once the cause is confirmed.
             */
            try {
                log.debug(SCRIPT_ID + ' | Line ' + (i + 1) + ' Commit Check',
                    'committedQty=' + rec.getCurrentSublistValue({
                        sublistId: sublistId, fieldId: 'quantitycommitted' }) +
                    ' | commitPolicy=' + rec.getCurrentSublistValue({
                        sublistId: sublistId, fieldId: 'commitinventory' }));
            } catch (diagErr) {
                log.debug(SCRIPT_ID + ' | Line ' + (i + 1) + ' Commit Check',
                    'Diagnostic read failed (' + diagErr.name + ') — non-fatal.');
            }

            /* ── 5b. Skip lines that cannot carry inventory detail ──
             * Phantom sub-assemblies and any line whose commit policy is
             * "Do Not Commit" (commitinventory === 3) commit nothing, so
             * NetSuite will not create an inventory detail subrecord for
             * them.  Asking for one throws:
             *   "You cannot create an inventory detail for this item."
             * Detect and skip these BEFORE requesting the subrecord.
             */
            var commitPolicy = parseInt(rec.getCurrentSublistValue({
                sublistId: sublistId,
                fieldId:   'commitinventory'
            }), 10);

            if (commitPolicy === COMMIT_DO_NOT) {
                rec.cancelLine({ sublistId: sublistId });
                log.debug(SCRIPT_ID + ' | Line ' + (i + 1),
                    'Item ' + itemId + ' has commit policy "Do Not Commit"' +
                    ' (phantom / non-committing) — no inventory detail possible. Skipping.');
                continue;
            }

            /*
             * Guard the subrecord access itself.  Even with a normal commit
             * policy, some items/locations are not inventory-detail eligible;
             * getCurrentSublistSubrecord throws rather than returning null.
             * Skip (defer) any such line instead of blocking the WO save.
             */
            var invDetail;
            try {
                invDetail = rec.getCurrentSublistSubrecord({
                    sublistId: sublistId,
                    fieldId:   'inventorydetail'
                });
            } catch (detailErr) {
                rec.cancelLine({ sublistId: sublistId });
                log.audit(SCRIPT_ID + ' | Line ' + (i + 1) + ' Skipped (No Detail Allowed)',
                    'Item ' + itemId + ' — NetSuite will not create inventory detail (' +
                    detailErr.message + '). Skipping.');
                continue;
            }

            /* ── 5a. Preserve existing inventory detail ── */
            var existingCount = invDetail.getLineCount({
                sublistId: 'inventoryassignment'
            });

            if (existingCount > 0) {
                /*
                 * This line already has inventory detail — either
                 * written by this script on a prior save or entered
                 * manually by the user.  Cancel the line edit and
                 * move on; we must never overwrite.
                 */
                rec.cancelLine({ sublistId: sublistId });
                log.debug(SCRIPT_ID + ' | Line ' + (i + 1),
                    'Item ' + itemId + ' already has ' + existingCount +
                    ' assignment line(s) — preserving (no re-processing).');
                preserved++;
                continue;
            }

            /* ── 6. Query available lots ── */
            var availableLots = util.getAvailableLots(itemId, locationId);
            log.debug(SCRIPT_ID + ' | Line ' + (i + 1) + ' Available Lots',
                'Found ' + availableLots.length + ' lot(s)');

            if (!availableLots || availableLots.length === 0) {
                rec.cancelLine({ sublistId: sublistId });
                log.audit(SCRIPT_ID + ' | Line ' + (i + 1) + ' Deferred',
                    'Item ' + itemId + ' — no lots available at location ' +
                    locationId + '. Inventory detail left blank.');
                deferred++;
                continue;
            }

            /* ── 7. Run lot-selection algorithm ── */
            var result = util.selectLots(availableLots, quantity);

            if (!result.success) {
                rec.cancelLine({ sublistId: sublistId });
                var itemName = rec.getSublistText({
                    sublistId: sublistId,
                    fieldId:   'item',
                    line:      i
                });
                log.audit(SCRIPT_ID + ' | Line ' + (i + 1) + ' Deferred',
                    'Component (' + itemName + '): required ' + quantity +
                    ' but only ' + (quantity - result.shortfall) +
                    ' available. Inventory detail left blank.');
                deferred++;
                continue;
            }

            /* ── 8. Write inventory detail with spill-over ──
             *
             * Single forward pass: try each selected lot via tryWriteLot.
             * If a lot gives less than requested (engine caps it), the
             * deficit spills over to the remaining available lots.
             * No re-selection, no retry loop on the component line.
             */
            log.audit(SCRIPT_ID + ' | Line ' + (i + 1) + ' Lots Selected',
                'Selected ' + result.lines.length + ' lot(s) for qty=' +
                quantity + ' | ' + JSON.stringify(result.lines));

            var lineLabel    = 'Line ' + (i + 1);
            var usedLotIds   = {};
            var totalWritten = 0;

            /* Phase 1 — write the lots selectLots chose */
            for (var k = 0; k < result.lines.length; k++) {
                var written = tryWriteLot(
                    invDetail, result.lines[k].lotId,
                    result.lines[k].qty, lineLabel);

                if (written > 0) {
                    usedLotIds[result.lines[k].lotId] = true;
                    totalWritten += written;
                }
            }

            /* Phase 2 — spill deficit to unused available lots */
            var deficit = quantity - totalWritten;

            if (deficit > 0) {
                log.audit(SCRIPT_ID + ' | ' + lineLabel + ' Spill-over',
                    'Short by ' + deficit +
                    ' after selected lots. Trying remaining available lots.');

                for (var m = 0; m < availableLots.length && deficit > 0; m++) {
                    if (usedLotIds[availableLots[m].lotId]) { continue; }

                    var drawQty = Math.min(availableLots[m].availableQty, deficit);
                    var spillWritten = tryWriteLot(
                        invDetail, availableLots[m].lotId,
                        drawQty, lineLabel);

                    if (spillWritten > 0) {
                        usedLotIds[availableLots[m].lotId] = true;
                        totalWritten += spillWritten;
                        deficit      -= spillWritten;
                    }
                }
            }

            /* ── Commit or defer ── */
            if (totalWritten >= quantity) {
                rec.commitLine({ sublistId: sublistId });
                assigned++;
                log.debug(SCRIPT_ID + ' | ' + lineLabel + ' Detail Written',
                    'Wrote lot(s) totalling qty=' + totalWritten +
                    ' successfully.');
            } else {
                rec.cancelLine({ sublistId: sublistId });
                log.audit(SCRIPT_ID + ' | ' + lineLabel + ' Deferred',
                    'Could only assign ' + totalWritten + ' of ' +
                    quantity + ' required. Inventory detail left ' +
                    'blank for manual entry.');
                deferred++;
            }
        }

        /* ── Save the record with inventory detail ── */
        if (assigned > 0) {
            rec.save({ enableSourcing: true, ignoreMandatoryFields: true });
            log.audit(SCRIPT_ID + ' | Saved',
                'WO ' + woId + ' saved with inventory detail on ' +
                assigned + ' line(s).');
        } else {
            log.debug(SCRIPT_ID + ' | No Save Needed',
                'No lines required inventory detail writes this pass.');
        }

        log.debug(SCRIPT_ID + ' | afterSubmit Exit',
            'Completed. Lines: ' + lineCount +
            ' | Assigned: ' + assigned +
            ' | Preserved: ' + preserved +
            ' | Deferred: ' + deferred);
    }

    return {
        afterSubmit: afterSubmit
    };
});