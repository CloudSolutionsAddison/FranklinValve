/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 *
 * Franklin Valve — Auto Lot: Transfer Order (Subprocess 1.3)
 *
 * beforeSubmit: for every lot-numbered item line on a Transfer Order,
 * automatically select and assign inventory lots from the SOURCE
 * location using the shared FV lot-selection algorithm (lowest-bin-quantity first).
 *
 * Behaviour by scenario:
 *
 *   ITEM AVAILABLE AT SOURCE — Inventory Detail is auto-populated
 *                               using lowest-bin-quantity logic.
 *
 *   ITEM NOT AVAILABLE /      — Inventory Detail is left blank.
 *   PARTIAL QTY ONLY           The save is NEVER blocked.
 *                               The client may populate it manually
 *                               once stock is available, or simply
 *                               edit & re-save the TO for the script
 *                               to re-evaluate automatically.
 *
 *   EDIT / QTY CHANGE         — The script re-evaluates every
 *                               qualifying line on every save.  If
 *                               the ordered qty changed and stock can
 *                               no longer cover it, existing detail
 *                               is cleared.  If the new qty CAN be
 *                               covered, detail is (re-)written to
 *                               match.
 *
 *   SERIALIZED ASSEMBLIES     — Skipped entirely; serial selection is
 *                               manual and outside this automation.
 *
 *
 * @module bpc_fv_auto_lot_to_ue
 */
define([
    'N/log',
    'N/runtime',
    './bpc_fv_auto_lot_util'
], function (log, runtime, lotUtil) {

    

    /**
     * beforeSubmit — Auto-assign lots on Transfer Order item lines.
     *
     * @param {Object} context
     * @param {Record} context.newRecord
     * @param {string} context.type  - create | edit | …
     */
    function beforeSubmit(context) {
        var triggerType = context.type;

        if (triggerType !== context.UserEventType.CREATE &&
            triggerType !== context.UserEventType.EDIT) {
            return;
        }

        var rec       = context.newRecord;
        var lineCount = rec.getLineCount({ sublistId: 'item' });

        log.debug('beforeSubmit ',
            'Processing TO ' + (rec.id || 'NEW') +
            ' | lines=' + lineCount +
            ' | trigger=' + triggerType);

        /*
         * SOURCE location resolution:
         *   1. Line-level 'location' field   (takes precedence)
         *   2. Header 'location' field       (fallback — the TO "From" location)
         *
         * The Transfer Order header has two location fields:
         *   • 'location'        — the source / "From" location
         *   • 'transferlocation' — the destination / "To" location
         * We always query inventory against the SOURCE location.
         */
        var headerSourceLocation = rec.getValue({ fieldId: 'location' });

        var assigned = 0;
        var cleared  = 0;
        var deferred = 0;

        for (var i = 0; i < lineCount; i++) {

            var itemId = rec.getSublistValue({
                sublistId: 'item',
                fieldId:   'item',
                line:      i
            });

            if (!itemId) { continue; }

            /* ── 1. Skip serialized assembly items ── */
            try {
                if (lotUtil.isSerializedAssembly(itemId)) {
                    log.debug( '  Line ' + i,
                        'Item ' + itemId +
                        ' is a serialized assembly — skipping (manual serial selection).');
                    continue;
                }
            } catch (e) {
                log.debug(  ' Line ' + i,
                    'Serialized-assembly check error for item ' + itemId +
                    ' (' + e.name + ') — continuing.');
            }

            /* ── 2. Check if lot-numbered ── */
            var isLot;
            try {
                isLot = lotUtil.isLotNumbered(itemId);
            } catch (e) {
                log.debug( ' Line ' + i,
                    'Item ' + itemId +
                    ' not lot-checkable (' + e.name + ') — skipping.');
                continue;
            }

            if (!isLot) {
                log.debug( ' Line ' + i,
                    'Item ' + itemId + ' is not lot-numbered — skipping.');
                continue;
            }

            /* ── 3. Read quantity ── */
            var quantity = parseFloat(rec.getSublistValue({
                sublistId: 'item',
                fieldId:   'quantity',
                line:      i
            })) || 0;

            if (quantity <= 0) { continue; }

            /* ── 4. Resolve source location ── */
            var lineLocationId = rec.getSublistValue({
                sublistId: 'item',
                fieldId:   'location',
                line:      i
            });

            var sourceLocationId = lineLocationId || headerSourceLocation;

            if (!sourceLocationId) {
                log.audit( ' Line ' + i,
                    'Item ' + itemId +
                    ' — no source location resolved (line or header) — skipping.');
                continue;
            }

            /* ── 5. Look up available lots at the source location ── */
            var availableLots = lotUtil.getAvailableLots(itemId, sourceLocationId);

            if (!availableLots || availableLots.length === 0) {
                log.audit( ' Line ' + i,
                    'Item ' + itemId +
                    ' — no lots available at source location ' + sourceLocationId +
                    '. Inventory detail left blank (deferred).');

                _safeClearDetail(rec, i, itemId);
                deferred++;
                continue;
            }

            /* ── 6. Run lot-selection algorithm ── */
            var selection = lotUtil.selectLotsGreedyMax(availableLots, quantity);

            if (!selection.success) {
                /*
                 * PARTIAL FULFILMENT IS NOT ALLOWED.
                 * If available stock at the source location cannot cover
                 * the ENTIRE line quantity, the inventory detail is left
                 * blank.  The user can either populate it manually or
                 * edit & re-save the TO once stock is available — at
                 * which point this script will re-evaluate automatically.
                 */
                log.audit( ' Line ' + i,
                    'Item ' + itemId +
                    ' — shortfall of ' + selection.shortfall +
                    ' at source location ' + sourceLocationId +
                    '. Inventory detail left blank (deferred).');

                _safeClearDetail(rec, i, itemId);
                deferred++;
                continue;
            }

            /* ── 7. Write inventory detail ── */
            try {
                lotUtil.writeInventoryDetail(rec, 'item', i, selection.lines);

                log.debug( ' Line ' + i,
                    'Assigned ' + selection.lines.length +
                    ' lot(s) for qty ' + quantity +
                    ' | Lots: ' + JSON.stringify(selection.lines.map(function (l) {
                        return { lot: l.lotNumber, qty: l.qty };
                    })));
                assigned++;
            } catch (e) {
                log.error( ' Line ' + i,
                    'writeInventoryDetail failed — ' +
                    e.name + ': ' + e.message);
                deferred++;
            }
        }

        log.debug( '  beforeSubmit Exit',
            'Completed. Lines: ' + lineCount +
            ' | Assigned: ' + assigned +
            ' | Cleared: ' + cleared +
            ' | Deferred: ' + deferred);
    }

    /* ------------------------------------------------------------------ *
     *  PRIVATE HELPERS                                                    *
     * ------------------------------------------------------------------ */

    /**
     * Attempt to clear existing inventory detail on a line.
     * Swallows errors so it never blocks the save.
     *
     * On edit, a line may carry stale detail from a prior save where
     * stock was sufficient.  If the quantity changed (or stock was
     * consumed elsewhere) and lots can no longer cover the full qty,
     * the old detail must be wiped so the line is left genuinely blank
     * for the client to handle.
     *
     * @param {Record} rec
     * @param {number} lineIdx
     * @param {number|string} itemId  - For logging only
     */
    function _safeClearDetail(rec, lineIdx, itemId) {
        try {
            lotUtil.clearInventoryDetail(rec, 'item', lineIdx);
            log.debug(  ' _safeClearDetail',
                'Line ' + lineIdx + ': cleared existing inventory detail for item ' + itemId);
        } catch (e) {
            /*
             * Not every line will have an openable inventory detail
             * subrecord (e.g. first create, or non-lot items that
             * slipped through).  This is expected — do not escalate.
             */
            log.debug(' _safeClearDetail',
                'Line ' + lineIdx + ': clearInventoryDetail skipped — ' + e.message);
        }
    }

    return {
        beforeSubmit: beforeSubmit
    };
});
