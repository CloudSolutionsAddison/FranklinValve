/**
 * @NApiVersion 2.1
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 *
 * Franklin Valve — Auto Lot: Assembly Build Client Script
 *
 * Deployed on the Assembly Build (Work Order Issue) form.
 *
 * In saveRecord (which fires BEFORE NetSuite's native inventory-detail
 * validation), this script:
 *   1. Collects every component line that does not already have lot
 *      assignments.
 *   2. POSTs to the Auto Lot Suitelet, which runs the shared lot-
 *      selection algorithm server-side.
 *   3. Writes the returned lot selections into each line's Inventory
 *      Detail subrecord (dynamic mode — available client-side).
 *   4. Returns true to allow the save, or false + alert on shortfall.
 *
 * Functional Design Ref: FDD v0.3, Section 1.2 (FR-09)
 */
define([
    'N/url',
    'N/log'
], function (url, log) {

    /**
     * ── Suitelet identifiers ──
     * Update these after the Suitelet script record is created.
     */
    var SL_SCRIPT_ID = 'customscript_bpc_woissue_sl';
    var SL_DEPLOY_ID = 'customdeploy1';

    var SCRIPT_ID = 'FV_AutoLot_CS';

    /* ================================================================== *
     *  pageInit  (required entry point — no-op)                           *
     * ================================================================== */
    function pageInit(context) {
        // intentionally empty — required by NetSuite for client scripts
    }

    /* ================================================================== *
     *  saveRecord                                                         *
     * ================================================================== */

    /**
     * Fires after the user clicks Save but BEFORE NetSuite validates
     * that inventory detail is present on lot-tracked lines.
     *
     * @param {Object} context
     * @param {currentRecord.CurrentRecord} context.currentRecord
     * @returns {boolean} true = allow save, false = block
     */
    function saveRecord(context) {
        var rec = context.currentRecord;

        // ── Determine which sublist holds the components ──
        // Work Order Issue uses 'item'; Assembly Build uses 'component'.
        // Try 'item' first (supports inventory detail subrecord).
        var sublistId = 'item';
        var lineCount = rec.getLineCount({ sublistId: sublistId });

        if (lineCount <= 0) {
            sublistId = 'component';
            lineCount = rec.getLineCount({ sublistId: sublistId });
        }

        console.log(SCRIPT_ID + ' | saveRecord | Sublist: ' + sublistId +
                    ' | Lines: ' + lineCount);

        // ── Step 1: Collect all component lines ──
        // We do NOT probe inventorydetail here — client-side NS throws
        // a framework error on non-lot items that bypasses try/catch.
        // The Suitelet determines which items are lot-tracked.
        var linesToProcess = [];

        for (var i = 0; i < lineCount; i++) {
            var itemId     = rec.getSublistValue({ sublistId: sublistId, fieldId: 'item',     line: i });
            var quantity   = rec.getSublistValue({ sublistId: sublistId, fieldId: 'quantity', line: i });
            var locationId = rec.getSublistValue({ sublistId: sublistId, fieldId: 'location', line: i });

            linesToProcess.push({
                line:       i,
                itemId:     itemId,
                locationId: locationId,
                quantity:   parseFloat(quantity) || 0
            });
        }

        if (linesToProcess.length === 0) {
            console.log(SCRIPT_ID + ' | No lines need auto-lot. Proceeding with save.');
            return true;
        }

        // ── Step 2: Call the Suitelet ──
        var response;
        try {
            response = callSuitelet(linesToProcess);
        } catch (e) {
            alert('Auto Lot error — could not reach lot selection service.\n\n' +
                  e.message + '\n\nSave has been blocked.');
            return false;
        }

        if (response.error) {
            alert('Auto Lot error — ' + response.error + '\n\nSave has been blocked.');
            return false;
        }

        // ── Step 3: Write inventory detail & check for shortfalls ──
        var errors  = [];
        var results = response.results || [];

        for (var j = 0; j < results.length; j++) {
            var r = results[j];

            if (!r.isLotTracked) continue;           // not a lot item — skip
            if (!r.lots || r.lots.length === 0) continue;  // nothing to write

            if (!r.success) {
                var itemName = rec.getSublistText({
                    sublistId: sublistId,
                    fieldId:   'item',
                    line:      r.line
                });
                errors.push(
                    'Line ' + (r.line + 1) + ' (' + itemName + '): short ' +
                    r.shortfall + ' unit(s).'
                );
                continue;
            } 

            // Write lots into inventory detail (dynamic mode)
            writeLotDetail(rec, sublistId, r.line, r.lots);

            console.log(SCRIPT_ID + ' | Line ' + r.line +
                        ' — wrote ' + r.lots.length + ' lot(s).');
        }

        if (errors.length > 0) {
            alert('Auto Lot blocked — insufficient lot quantity:\n\n' +
                  errors.join('\n'));
            return false;
        }

        console.log(SCRIPT_ID + ' | saveRecord complete. Allowing save.');
        return true;
    }

    /* ================================================================== *
     *  HELPERS                                                            *
     * ================================================================== */

    /**
     * Write lot selections into a component line's Inventory Detail
     * subrecord using dynamic-mode APIs (available client-side).
     *
     * @param {currentRecord.CurrentRecord} rec
     * @param {string} sublistId
     * @param {number} lineIdx
     * @param {Array<{lotNumber: string, lotId: string, qty: number}>} lots
     */
    function writeLotDetail(rec, sublistId, lineIdx, lots) {
        rec.selectLine({ sublistId: sublistId, line: lineIdx });

        var invDetail = rec.getCurrentSublistSubrecord({
            sublistId: sublistId,
            fieldId:   'inventorydetail'
        });

        // Clear any auto-populated lines
        var existing = invDetail.getLineCount({ sublistId: 'inventoryassignment' });
        for (var r = existing - 1; r >= 0; r--) {
            invDetail.removeLine({ sublistId: 'inventoryassignment', line: r });
        }

        // Write lot assignments
        for (var k = 0; k < lots.length; k++) {
            invDetail.selectNewLine({ sublistId: 'inventoryassignment' });

            invDetail.setCurrentSublistValue({
                sublistId: 'inventoryassignment',
                fieldId:   'issueinventorynumber',
                value:     lots[k].lotId
            });

            invDetail.setCurrentSublistValue({
                sublistId: 'inventoryassignment',
                fieldId:   'quantity',
                value:     lots[k].qty
            });

            invDetail.commitLine({ sublistId: 'inventoryassignment' });
        }

        rec.commitLine({ sublistId: sublistId });
    }

    /**
     * Synchronous POST to the Auto Lot Suitelet.
     *
     * N/https is async-only in client scripts and saveRecord must
     * return a boolean synchronously, so we use a synchronous
     * XMLHttpRequest.
     *
     * @param {Array} lines - Component lines to process
     * @returns {Object}    - Parsed JSON response
     */
    function callSuitelet(lines) {
        var suiteletUrl = url.resolveScript({
            scriptId:     SL_SCRIPT_ID,
            deploymentId: SL_DEPLOY_ID,
            returnExternalUrl: false
        });

        var xhr = new XMLHttpRequest();
        xhr.open('POST', suiteletUrl, false);   // false = synchronous
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.send(JSON.stringify({ lines: lines }));

        if (xhr.status !== 200) {
            throw new Error('Suitelet returned HTTP ' + xhr.status);
        }

        return JSON.parse(xhr.responseText);
    }

    /* ================================================================== *
     *  ENTRY POINTS                                                       *
     * ================================================================== */

    return {
        pageInit:   pageInit,
        saveRecord: saveRecord
    };
});