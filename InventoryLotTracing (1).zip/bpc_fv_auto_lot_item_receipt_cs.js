/**
 * @NApiVersion 2.1
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 *
 * Franklin Valve — Auto Lot: Item Receipt (Client Script)
 *
 * ============================================================================
 *  WHY THIS SCRIPT LOOKS DIFFERENT FROM A "NORMAL" SUBLIST SCRIPT
 * ============================================================================
 *  On an Item Receipt (and Item Fulfillment) the "item" sublist is a LIST
 *  sublist, NOT an inline-editor sublist. There is no "current line" buffer,
 *  so the usual accessors return null / do nothing:
 *
 *      getCurrentSublistValue      -> null
 *      selectLine / commitLine     -> no-op / SSS_INVALID_SUBLIST_OPERATION
 *      getCurrentSublistSubrecord  -> needs a current line that never exists
 *
 *  Everything therefore uses an EXPLICIT line index instead:
 *
 *      rec.getSublistValue({ sublistId, fieldId, line })
 *      rec.getSublistText({ sublistId, fieldId, line })
 *      rec.getSublistSubrecord({ sublistId, fieldId, line })   <- inv detail
 *
 *  In fieldChanged the edited line arrives as context.line.
 *  In pageInit we loop 0 .. lineCount-1.
 *
 * ============================================================================
 *  LOGGING
 * ============================================================================
 *  All output is prefixed with "[FV_AutoLot]" and a stage tag, so you can:
 *    - Browser console: type FV_AutoLot in the console filter box to isolate.
 *    - Script Execution Log: entries are titled FV_AutoLot:<stage>.
 *  Set DEBUG = false to keep only audit/error (quieter for production).
 *  The key diagnostic line for the client-side subrecord question is
 *  "populate.verify" — it re-reads the inventory detail after commit and
 *  reports whether the assignment line actually stuck in the buffer.
 *
 * Functional Design Ref: FDD v0.3, Section 1.1
 */
define([
    'N/search',
    'N/ui/dialog',
    'N/log'
], function (search, dialog, log) {

    'use strict';

    /* ------------------------------------------------------------------ *
     *  CONSTANTS                                                          *
     * ------------------------------------------------------------------ */

    var ITEM_SUBLIST = 'item';
    var INV_DETAIL   = 'inventorydetail';
    var INV_ASSIGN   = 'inventoryassignment';

    var VENDOR_PART_NUM_RECORD = 'customrecord_bpc_fv_vpn';
    var VPN_VENDOR = 'name';
    var VPN_ITEM   = 'custrecord_bpc_fv_item';
    var VPN_CODE   = 'custrecord_bpc_ui_vendorlist';

    // >>> REPLACE with the actual internal IDs from the target account <<<
    var DEFAULT_BIN_ID        = 123;   // internal ID of "11-QA-INSP"
    var DEFAULT_INV_STATUS_ID = 1;     // internal ID of "Good"

    /* ------------------------------------------------------------------ *
     *  LOGGING                                                            *
     * ------------------------------------------------------------------ */

    var DEBUG      = true;            // flip to false to silence dbg() output
    var LOG_PREFIX = '[FV_AutoLot]';

    function fmt(details) {
        if (details === undefined || details === null) return '';
        return (typeof details === 'object') ? JSON.stringify(details) : String(details);
    }

    // Verbose trace — console + Script Execution Log (debug). Gated by DEBUG.
    function dbg(stage, details) {
        if (!DEBUG) return;
        var msg = fmt(details);
        try { console.log(LOG_PREFIX + ' ' + stage + (msg ? ' | ' + msg : '')); } catch (ignore) {}
        log.debug({ title: 'FV_AutoLot:' + stage, details: msg });
    }

    // Milestone — always emitted (console + audit).
    function audit(stage, details) {
        var msg = fmt(details);
        try { console.log(LOG_PREFIX + ' ' + stage + (msg ? ' | ' + msg : '')); } catch (ignore) {}
        log.audit({ title: 'FV_AutoLot:' + stage, details: msg });
    }

    // Errors — always emitted (console.error keeps the stack in the browser).
    function err(stage, e) {
        try { console.error(LOG_PREFIX + ' ERROR ' + stage, e); } catch (ignore) {}
        log.error({ title: 'FV_AutoLot:' + stage, details: (e && e.stack) || (e && e.message) || fmt(e) });
    }

    /* ------------------------------------------------------------------ *
     *  MODULE-LEVEL CACHE (persists for the life of the loaded form)     *
     * ------------------------------------------------------------------ */

    var lotItemCache    = {};   // { itemId : bool }
    var vendorCodeCache = {};   // { "vendorId|itemId" : code | null }

    /* ================================================================== *
     *  ENTRY POINT 1 — pageInit                                           *
     * ================================================================== */

    function pageInit(context) {
        audit('pageInit.enter', { mode: context.mode });

        if (context.mode !== 'create' && context.mode !== 'copy') {
            dbg('pageInit.skip', 'mode is ' + context.mode + ' (only create/copy processed)');
            return;
        }

        var rec = context.currentRecord;
        var vendorId = rec.getValue('entity');
        if (!vendorId) {
            audit('pageInit.skip', 'no vendor (entity) on header');
            return;
        }
        dbg('pageInit.vendor', vendorId);

        var lineCount = rec.getLineCount({ sublistId: ITEM_SUBLIST });
        audit('pageInit.lineCount', lineCount);

        var missing = [];
        var populated = 0;
        for (var i = 0; i < lineCount; i++) {
            try {
                var res = processLine(rec, i, vendorId);
                if (res && res.missing) missing.push(res.missing);
                else if (res && res.populated) populated++;
            } catch (e) {
                err('pageInit.line[' + i + ']', e);
            }
        }

        audit('pageInit.summary', { lines: lineCount, populated: populated, missingMappings: missing.length });

        if (missing.length) {
            dbg('pageInit.dialog', 'showing ' + missing.length + ' missing-mapping warning(s)');
            dialog.alert({
                title:   'Missing Vendor Part Number Mapping(s)',
                message: 'The following line(s) have no active Vendor Part ' +
                         'Number mapping and will be blocked on save:\n\n' +
                         missing.join('\n')
            });
        }
    }

    /* ================================================================== *
     *  ENTRY POINT 2 — fieldChanged                                       *
     * ================================================================== */

    function fieldChanged(context) {
        // Cheap guard first, but log every fire at debug level so you can see
        // exactly what NetSuite reports when you touch a line.
        dbg('fieldChanged.fire', { sublistId: context.sublistId, fieldId: context.fieldId, line: context.line });

        if (context.sublistId !== ITEM_SUBLIST) return;
        if (context.fieldId !== 'quantity' && context.fieldId !== 'itemreceive') return;
        if (context.line === null || context.line === undefined) {
            dbg('fieldChanged.skip', 'no line index on context');
            return;
        }

        audit('fieldChanged.enter', { fieldId: context.fieldId, line: context.line });

        var rec = context.currentRecord;
        var vendorId = rec.getValue('entity');
        if (!vendorId) {
            dbg('fieldChanged.skip', 'no vendor on header');
            return;
        }

        try {
            var res = processLine(rec, context.line, vendorId);
            if (res && res.missing) {
                dbg('fieldChanged.dialog', 'missing mapping on line ' + context.line);
                dialog.alert({
                    title:   'Missing Vendor Part Number Mapping',
                    message: 'No active Vendor Part Number record was found ' +
                             'for this vendor and item.\n\nPlease create the ' +
                             'mapping before saving, or the receipt will be blocked.'
                });
            }
        } catch (e) {
            err('fieldChanged', e);
        }
    }

    /* ------------------------------------------------------------------ *
     *  LINE PROCESSING  — explicit line index, no line selection          *
     * ------------------------------------------------------------------ */

    /**
     * Returns:
     *   { missing: '...' }   vendor mapping absent (caller surfaces a dialog)
     *   { populated: true }  inventory detail written
     *   null                 line not applicable (not received / not lot / qty 0)
     */
    function processLine(rec, line, vendorId) {
        dbg('processLine.enter', { line: line });

        var itemId = rec.getSublistValue({
            sublistId: ITEM_SUBLIST,
            fieldId:   'item',
            line:      line
        });
        dbg('processLine.itemId', itemId);
        if (!itemId) {
            dbg('processLine.skip', 'line ' + line + ' has no itemId');
            return null;
        }

        // Skip lines that are not being received. getSublistValue returns the
        // committed checkbox value (boolean); on forms where the column is
        // hidden it can be '' / undefined, in which case the line receives by
        // default and we continue.
        var isReceiving = rec.getSublistValue({
            sublistId: ITEM_SUBLIST,
            fieldId:   'itemreceive',
            line:      line
        });
        dbg('processLine.itemreceive', isReceiving);
        if (isReceiving === false) {
            dbg('processLine.skip', 'line ' + line + ' not being received; clearing detail');
            clearInventoryDetail(rec, line);
            return null;
        }

        var lot = isLotNumbered(itemId);
        dbg('processLine.isLot', lot);
        if (!lot) {
            dbg('processLine.skip', 'item ' + itemId + ' is not lot-numbered');
            return null;
        }

        var quantity = parseFloat(rec.getSublistValue({
            sublistId: ITEM_SUBLIST,
            fieldId:   'quantity',
            line:      line
        })) || 0;
        dbg('processLine.quantity', quantity);
        if (quantity <= 0) {
            dbg('processLine.skip', 'line ' + line + ' quantity <= 0; clearing detail');
            clearInventoryDetail(rec, line);
            return null;
        }

        var vendorCode = lookupVendorCode(vendorId, itemId);
        dbg('processLine.vendorCode', vendorCode);
        if (!vendorCode) {
            var itemName = rec.getSublistText({
                sublistId: ITEM_SUBLIST,
                fieldId:   'item',
                line:      line
            });
            audit('processLine.missingMapping', { line: line, item: itemName });
            return { missing: 'Line: ' + itemName + ' — missing vendor code mapping' };
        }

        populateInventoryDetail(rec, line, vendorCode, quantity);
        audit('processLine.done', { line: line, item: itemId, lot: vendorCode, qty: quantity });
        return { populated: true };
    }

    /* ------------------------------------------------------------------ *
     *  INVENTORY DETAIL  — subrecord reached by line index                *
     * ------------------------------------------------------------------ */

    /**
     * Line-indexed subrecord accessor. Replacement for
     * getCurrentSublistSubrecord, which cannot be used on a list sublist
     * because there is no current line.
     */
    function getInvDetailSubrecord(rec, line) {
        return rec.getSublistSubrecord({
            sublistId: ITEM_SUBLIST,
            fieldId:   INV_DETAIL,
            line:      line
        });
    }

    function populateInventoryDetail(rec, line, vendorCode, quantity) {
        dbg('populate.enter', { line: line, vendorCode: vendorCode, quantity: quantity });

        var subrec = getInvDetailSubrecord(rec, line);
        if (!subrec) {
            err('populate.noSubrecord', 'getSublistSubrecord returned null/undefined on line ' + line);
            throw new Error('Inventory Detail subrecord unavailable on line ' + line + '.');
        }
        dbg('populate.subrecordOk', 'line ' + line);

        // Clear any existing assignment lines first (idempotent re-runs).
        var existing = subrec.getLineCount({ sublistId: INV_ASSIGN });
        dbg('populate.existingAssignments', existing);
        for (var i = existing - 1; i >= 0; i--) {
            subrec.removeLine({ sublistId: INV_ASSIGN, line: i });
        }
        dbg('populate.afterClear', subrec.getLineCount({ sublistId: INV_ASSIGN }));

        // Subrecord inherits the parent's dynamic mode (client record is
        // dynamic): selectNewLine / setCurrentSublistValue / commitLine.
        subrec.selectNewLine({ sublistId: INV_ASSIGN });
        subrec.setCurrentSublistValue({ sublistId: INV_ASSIGN, fieldId: 'receiptinventorynumber', value: vendorCode });
        subrec.setCurrentSublistValue({ sublistId: INV_ASSIGN, fieldId: 'quantity',               value: quantity });
        subrec.setCurrentSublistValue({ sublistId: INV_ASSIGN, fieldId: 'binnumber',              value: DEFAULT_BIN_ID });
        subrec.setCurrentSublistValue({ sublistId: INV_ASSIGN, fieldId: 'inventorystatus',        value: DEFAULT_INV_STATUS_ID });
        subrec.commitLine({ sublistId: INV_ASSIGN });

        audit('populate.committed', { line: line, assignmentsNow: subrec.getLineCount({ sublistId: INV_ASSIGN }) });

        // --- KEY DIAGNOSTIC -------------------------------------------------
        // Re-read the subrecord fresh and confirm the assignment survived. If
        // this comes back < 1, the client-side subrecord write is NOT taking
        // on this record/config and you should move populate to a beforeSubmit
        // user event instead.
        if (DEBUG) {
            try {
                var verify = getInvDetailSubrecord(rec, line);
                var vCount = verify ? verify.getLineCount({ sublistId: INV_ASSIGN }) : -1;
                if (vCount < 1) {
                    err('populate.verify', 'reread assignment count = ' + vCount +
                        ' -- WRITE DID NOT STICK (client-side subrecord not writable here)');
                } else {
                    dbg('populate.verify', 'reread assignment count = ' + vCount + ' (ok)');
                }
            } catch (e) {
                err('populate.verify', e);
            }
        }
    }

    function clearInventoryDetail(rec, line) {
        try {
            var subrec = getInvDetailSubrecord(rec, line);
            if (!subrec) {
                dbg('clear.noSubrecord', 'line ' + line);
                return;
            }
            var count = subrec.getLineCount({ sublistId: INV_ASSIGN });
            dbg('clear.assignments', { line: line, count: count });
            for (var i = count - 1; i >= 0; i--) {
                subrec.removeLine({ sublistId: INV_ASSIGN, line: i });
            }
        } catch (e) {
            err('clear', e);
        }
    }

    /* ------------------------------------------------------------------ *
     *  HELPERS                                                            *
     * ------------------------------------------------------------------ */

    function isLotNumbered(itemId) {
        var key = String(itemId);
        if (lotItemCache.hasOwnProperty(key)) {
            dbg('isLot.cacheHit', { item: key, isLot: lotItemCache[key] });
            return lotItemCache[key];
        }

        var isLot = false;
        try {
            var fields = search.lookupFields({
                type:    search.Type.ITEM,
                id:      itemId,
                columns: ['islotitem']
            });
            isLot = fields.islotitem === true || fields.islotitem === 'T';
            dbg('isLot.lookup', { item: key, isLot: isLot });
        } catch (e) {
            err('isLotNumbered[' + key + ']', e);
        }
        lotItemCache[key] = isLot;
        return isLot;
    }

    function lookupVendorCode(vendorId, itemId) {
        var key = vendorId + '|' + itemId;
        // if (vendorCodeCache.hasOwnProperty(key)) {
        //     dbg('vendorCode.cacheHit', { key: key, code: vendorCodeCache[key] });
        //     return vendorCodeCache[key];
        // }

        var code = null;
        try {
            search.create({
                type: VENDOR_PART_NUM_RECORD,
                filters: [
                    [VPN_CODE, 'anyof', vendorId],
                    'AND',
                    [VPN_ITEM,   'anyof', itemId],
                    'AND',
                    ['isinactive', 'is', 'F']
                ],
                columns: [VPN_VENDOR]
            }).run().each(function (r) {
                code = r.getValue(VPN_VENDOR);
                return false;   // first match only
            });
            dbg('vendorCode.search', { key: key, code: code });
        } catch (e) {
            err('lookupVendorCode[' + key + ']', e);
        }

        vendorCodeCache[key] = code;
        return code;
    }

    return {
        pageInit:     pageInit,
        fieldChanged: fieldChanged
    };
});